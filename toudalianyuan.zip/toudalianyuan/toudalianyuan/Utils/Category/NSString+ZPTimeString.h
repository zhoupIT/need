//
//  NSString+ZPTimeString.h
//  toudalianyuan
//
//  Created by Biao Geng on 2019/7/26.
//  Copyright © 2019年 Peng Zhou. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface NSString (ZPTimeString)
+ (NSString *) compareCurrentTime:(NSString *)str;
@end

NS_ASSUME_NONNULL_END
