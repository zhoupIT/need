//
//  NSString+ZPTimeString.m
//  toudalianyuan
//
//  Created by Biao Geng on 2019/7/26.
//  Copyright © 2019年 Peng Zhou. All rights reserved.
//

#import "NSString+ZPTimeString.h"

@implementation NSString (ZPTimeString)

+ (NSString *) compareCurrentTime:(NSString *)time
{
    NSTimeInterval timeIntervalx=[time doubleValue]/1000;
    NSDate *UTCDate = [NSDate dateWithTimeIntervalSince1970:timeIntervalx];
    NSTimeInterval  timeInterval = [UTCDate timeIntervalSinceNow];
    timeInterval = -timeInterval;
    long temp = 0;
    NSString *result;
    if (timeInterval < 60) {
        result = [NSString stringWithFormat:@"just now"];
    }
    else if((temp = timeInterval/60) <60){
        result = [NSString stringWithFormat:@"%ld minutes ago",temp];
    }
    
    else if((temp = temp/60) <24){
        result = [NSString stringWithFormat:@"%ld hours ago",temp];
    }
    
    else if((temp = temp/24) <30){
        result = [NSString stringWithFormat:@"%ld days ago",temp];
    }
    
    else if((temp = temp/30) <12){
        result = [NSString stringWithFormat:@"%ld months ago",temp];
    }
    else{
        temp = temp/12;
        result = [NSString stringWithFormat:@"%ld years ago",temp];
    }
    
    return  result;
}
@end
