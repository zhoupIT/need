//
//  ConfigDefine.h
//  EasyTrade
//
//  Created by smy on 2017/12/1.
//  Copyright © 2017年 Rohon. All rights reserved.
//

#ifndef ConfigDefine_h
#define ConfigDefine_h
//项目相关宏定义

#pragma mark - ——————— 服务器地址 ————————
#define SERVER_ENVIRONMENT kProduction

#define ZPBaseUrl @"http://49.232.45.64:8500" //正式
//192.168.8.19:8500
//https://www.royalzp.xyz
#define ZPBaseUploadUrl @"http://49.232.45.64:8500"

#define PRODUCT_VERSION     [[[NSBundle mainBundle] infoDictionary] valueForKey:@"CFBundleShortVersionString"]
#define ZPPFSCRegular @"PingFangSC-Regular"
#define ZPPFSCMedium @"PingFangSC-Medium"
#define ZPPFSCLight @"PingFangSC-Light"

#pragma mark - ——————— 字号相关 ————————
#define SYS_FONT(x) [UIFont systemFontOfSize:x]
//integer转换为string
#define String_Integer(value) [NSString stringWithFormat:@"%ld",value]

// 1物理像素的pt值，常用于画水平或垂直分割线，iOS7下一律为0.5
#define ONE_PIXEL 1.0f/([[UIScreen mainScreen] respondsToSelector:@selector(nativeScale)] ? [UIScreen mainScreen].nativeScale : 2);
/** 用户的信息的保存地址 */
#define ZPUserInfoPATH [NSHomeDirectory() stringByAppendingPathComponent:[NSString stringWithFormat:@"Documents/user.data"]]
#endif /* ConfigDefine_h */
