//
//  SingleObject.h
//  toudalianyuan
//
//  Created by Biao Geng on 2019/7/19.
//  Copyright © 2019年 Peng Zhou. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface SingleObject : NSObject

@end

NS_ASSUME_NONNULL_END
