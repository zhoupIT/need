//
//  ZPNetWorkTool.m
//  Uhealth
//
//  Created by Biao Geng on 2018/3/28.
//  Copyright © 2018年 Peng Zhou. All rights reserved.
//

#import "ZPNetWorkTool.h"
@interface ZPNetWorkTool()
@property (nonatomic, strong) NSMutableDictionary *taskDictionary;
@property (nonatomic, strong) NSDictionary *allApiMethods;
@end
@implementation ZPNetWorkTool
ZPSingletonM(ZPNetWorkTool)

#pragma mark - 网络请求
- (void)GETRequestWith:(NSString *)apiName parameters:(NSDictionary *)parameters progress:(void (^)(NSProgress *))progress success:(void (^)(NSURLSessionDataTask *, id))success failed:(void (^)(NSURLSessionDataTask *, NSError *))failed className:(__unsafe_unretained Class)className {
    NSString *classString = NSStringFromClass(className);
    if ([kUSER_DEFAULT objectForKey:@"jwt"]) {
        [[ZPNetWorkManager shareNetWorkManager].requestSerializer setValue:[kUSER_DEFAULT objectForKey:@"jwt"] forHTTPHeaderField:@"_IDENTIY_JWT_"];
    }
    NSURLSessionDataTask *dataTask = [[ZPNetWorkManager shareNetWorkManager] GET:self.allApiMethods[apiName] parameters:parameters progress:^(NSProgress * _Nonnull downloadProgress) {
        if (progress) {
            progress(downloadProgress);
        }
    } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
        ZPLog(@"请求地址%@,responseObject%@",self.allApiMethods[apiName],responseObject);
        NSMutableArray *taskArray = self.taskDictionary[classString];
        [taskArray removeObject:task];
        if (success) {
            if ([[responseObject objectForKey:@"code"] integerValue] == 200) {
                success(task, responseObject);
            }else {
                [MBProgressHUD hideHUD];
                [MBProgressHUD showError:[responseObject objectForKey:@"message"]];
            }
        }
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        ZPLog(@"error===%@, task%@", error, task);
        NSMutableArray *taskArray = self.taskDictionary[classString];
        [taskArray removeObject:task];
    }];
    
    [self addTaskToDictionaryWith:classString task:dataTask];
}


- (void)GETRequestWithUrlString:(NSString *)urlString parameters:(NSDictionary *)parameters progress:(void (^)(NSProgress *))progress success:(void (^)(NSURLSessionDataTask *, id))success failed:(void (^)(NSURLSessionDataTask *, NSError *))failed className:(__unsafe_unretained Class)className {
    NSString *classString = NSStringFromClass(className);
    if ([kUSER_DEFAULT objectForKey:@"jwt"]) {
        [[ZPNetWorkManager shareNetWorkManager].requestSerializer setValue:[kUSER_DEFAULT objectForKey:@"jwt"] forHTTPHeaderField:@"_IDENTIY_JWT_"];
    }
    NSURLSessionDataTask *dataTask = [[ZPNetWorkManager shareNetWorkManager] GET:urlString parameters:parameters progress:^(NSProgress * _Nonnull downloadProgress) {
        if (progress) {
            progress(downloadProgress);
        }
    } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
        ZPLog(@"responseObject%@", responseObject);
        NSMutableArray *taskArray = self.taskDictionary[classString];
        [taskArray removeObject:task];
        if (success) {
            if ([[responseObject objectForKey:@"code"] integerValue] == 200) {
                success(task, responseObject);
            }else {
                [MBProgressHUD hideHUD];
                [MBProgressHUD showError:[responseObject objectForKey:@"message"]];
            }
        }
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        ZPLog(@"error===%@, task%@", error, task);
        NSMutableArray *taskArray = self.taskDictionary[classString];
        [taskArray removeObject:task];
    }];
    
    [self addTaskToDictionaryWith:classString task:dataTask];
}

- (void)POSTRequestWith:(NSString *)apiName parameters:(NSDictionary *)parameters progress:(void (^)(NSProgress *))progress success:(void (^)(NSURLSessionDataTask *, id))success failed:(void (^)(NSURLSessionDataTask *, NSError *))failed className:(Class)className {
    NSString *classString = NSStringFromClass(className);
    if ([kUSER_DEFAULT objectForKey:@"jwt"]) {
        [[ZPNetWorkManager shareNetWorkManager].requestSerializer setValue:[kUSER_DEFAULT objectForKey:@"jwt"] forHTTPHeaderField:@"_IDENTIY_JWT_"];
    }
    NSURLSessionDataTask *dataTask = [[ZPNetWorkManager shareNetWorkManager] POST:self.allApiMethods[apiName] parameters:parameters progress:^(NSProgress * _Nonnull uploadProgress) {
        if (progress) {
            progress(uploadProgress);
        }
    } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
        ZPLog(@"responseObject%@", responseObject);
        NSMutableArray *taskArray = self.taskDictionary[classString];
        [taskArray removeObject:task];
        if (success) {
            if ([[responseObject objectForKey:@"code"] integerValue] == 200) {
                success(task, responseObject);
            } else {
                [MBProgressHUD hideHUD];
                [MBProgressHUD showError:[responseObject objectForKey:@"message"]];
            }
        }
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        ZPLog(@"error===%@, task%@", error, task);
        NSMutableArray *taskArray = self.taskDictionary[classString];
        [taskArray removeObject:task];
        
    }];
    
    [self addTaskToDictionaryWith:classString task:dataTask];
}

- (void)POSTRequestWithUrlString:(NSString *)urlString parameters:(NSDictionary *)parameters progress:(void (^)(NSProgress *))progress success:(void (^)(NSURLSessionDataTask *, id))success failed:(void (^)(NSURLSessionDataTask *, NSError *))failed className:(Class)className {
    NSString *classString = NSStringFromClass(className);
    if ([kUSER_DEFAULT objectForKey:@"jwt"]) {
        [[ZPNetWorkManager shareNetWorkManager].requestSerializer setValue:[kUSER_DEFAULT objectForKey:@"jwt"] forHTTPHeaderField:@"_IDENTIY_JWT_"];
    }
    NSURLSessionDataTask *dataTask = [[ZPNetWorkManager shareNetWorkManager] POST:urlString parameters:parameters progress:^(NSProgress * _Nonnull uploadProgress) {
        if (progress) {
            progress(uploadProgress);
        }
    } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
        ZPLog(@"responseObject%@", responseObject);
        NSMutableArray *taskArray = self.taskDictionary[classString];
        [taskArray removeObject:task];
        
        if (success) {
            if ([[responseObject objectForKey:@"code"] integerValue] == 200) {
                success(task, responseObject);
            }else {
                [MBProgressHUD hideHUD];
                [MBProgressHUD showError:[responseObject objectForKey:@"message"]];
            }
        }
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        ZPLog(@"error===%@, task%@", error, task);
        NSMutableArray *taskArray = self.taskDictionary[classString];
        [taskArray removeObject:task];
    }];
    
    [self addTaskToDictionaryWith:classString task:dataTask];
}

- (void)POSTRequestWith:(NSString *)apiName parameters:(NSDictionary *)parameters constructingBodyWithBlock:(void(^)(id<AFMultipartFormData> formData))block progress:(void (^)(NSProgress *))progress success:(void (^)(NSURLSessionDataTask *, id))success failed:(void (^)(NSURLSessionDataTask *, NSError *))failed className:(Class)className {
    NSString *classString = NSStringFromClass(className);
    if ([kUSER_DEFAULT objectForKey:@"jwt"]) {
        [[ZPNetWorkManager shareNetWorkManager].requestSerializer setValue:[kUSER_DEFAULT objectForKey:@"jwt"] forHTTPHeaderField:@"_IDENTIY_JWT_"];
    }
    NSURLSessionDataTask *dataTask = [[ZPNetWorkManager shareNetWorkManager] POST:self.allApiMethods[apiName] parameters:parameters constructingBodyWithBlock:^(id<AFMultipartFormData>  _Nonnull formData) {
        if (block) {
            block(formData);
        }
    } progress:^(NSProgress * _Nonnull uploadProgress) {
        if (progress) {
            progress(uploadProgress);
        }
    } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
        ZPLog(@"responseObject%@", responseObject);
        NSMutableArray *taskArray = self.taskDictionary[classString];
        [taskArray removeObject:task];
        if (success) {
            if ([[responseObject objectForKey:@"code"] integerValue] == 200) {
                success(task, responseObject);
            }
        }
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
         ZPLog(@"error===%@, task%@", error, task);
        NSMutableArray *taskArray = self.taskDictionary[classString];
        [taskArray removeObject:task];
    }];
    [self addTaskToDictionaryWith:classString task:dataTask];
    
}

- (void)cancelAllRequest {
    [[ZPNetWorkManager shareNetWorkManager].operationQueue cancelAllOperations];
}

- (void)cancelAllRequestsWith:(Class)className {
    NSString *classString = NSStringFromClass(className);
    NSMutableArray *taskArray = self.taskDictionary[classString];
    if (taskArray.count) {
        [taskArray enumerateObjectsUsingBlock:^(NSURLSessionTask *  _Nonnull task, NSUInteger idx, BOOL * _Nonnull stop) {
            [task cancel];
        }];
        [self.taskDictionary removeObjectForKey:className];
    }
}

- (void)addTaskToDictionaryWith:(NSString *)className task:(NSURLSessionTask *)task {
    if (task !=nil) {
        NSMutableArray *taskArray = self.taskDictionary[className];
        if (taskArray == nil) {
            taskArray = [NSMutableArray array];
            self.taskDictionary[className] = taskArray;
        }
        [taskArray addObject:task];
    }
}

- (NSMutableDictionary *)taskDictionary {
    if (!_taskDictionary) {
        _taskDictionary = [NSMutableDictionary dictionary];
    }
    return _taskDictionary;
}

- (NSDictionary *)allApiMethods {
    if (!_allApiMethods) {
        _allApiMethods = @{
                           @"register":@"/api/customer/register",
                           @"login":@"/api/customer/login",
                           @"upload":@"/api/file/upload",
                           @"customer":@"/api/customer",
                           @"show":@"/api/customer/show",
                           @"shareList":@"/api/share/list",
                           @"share":@"/api/share"
                           };
    }
    return _allApiMethods;
}
@end
