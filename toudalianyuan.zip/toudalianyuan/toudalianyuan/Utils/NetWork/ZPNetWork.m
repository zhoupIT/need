//
//  ZPNetWork.m
//  Uhealth
//
//  Created by Biao Geng on 2018/5/24.
//  Copyright © 2018年 Peng Zhou. All rights reserved.
//

#import "ZPNetWork.h"
@implementation ZPNetWork

ZPSingletonM(ZPNetWork)

- (void)requestWithUrl:(NSString *)urlStr andHTTPMethod:(NSString *)httpMethod andDict:(NSDictionary *)dict success:(void(^)(NSDictionary *response))success failed:(void (^)(NSError *error))failed {
    NSURL *url = [NSURL URLWithString:[NSString stringWithFormat:@"%@/%@",ZPBaseUrl,urlStr]];
    
    NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:url];
    
    request.HTTPMethod = httpMethod;
    if ([kUSER_DEFAULT objectForKey:@"jwt"]) {
        request.allHTTPHeaderFields = @{@"Content-Type":@"application/json",@"_IDENTIY_JWT_":[kUSER_DEFAULT objectForKey:@"jwt"]};
    } else {
        request.allHTTPHeaderFields = @{@"Content-Type":@"application/json"};//此处为请求头，类型为字典
    }
    if (dict == nil) {
        dict = @{};
    }
    NSDictionary *msg = dict;
    
    NSData *data = [NSJSONSerialization dataWithJSONObject:msg options:NSJSONWritingPrettyPrinted error:nil];
    
    request.HTTPBody = data;
    
    [[[NSURLSession sharedSession] dataTaskWithRequest:request completionHandler:^(NSData *data, NSURLResponse *response, NSError *error) {
        ZPLog(@"%@ --------%@",[[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding],error);
        dispatch_async(dispatch_get_main_queue(), ^{
             [MBProgressHUD hideHUD];
            if (error == nil) {
                NSDictionary *dict = [data mj_JSONObject];
                if ([[dict objectForKey:@"code"] integerValue]  == 200) {
                    if (success) {
                       success(dict);
                    }
                } else {
                    [MBProgressHUD showError:[dict objectForKey:@"message"]];
                    if (failed) {
                        failed(error);
                    }
                }
            } else {
                [MBProgressHUD showError:error.localizedDescription];
                if (failed) {
                    failed(error);
                }
            }
        });
        
    }] resume];
}
@end
