//
//  EnumDefine.h
//  toudalianyuan
//
//  Created by Biao Geng on 2019/7/25.
//  Copyright © 2019年 Peng Zhou. All rights reserved.
//

#ifndef EnumDefine_h
#define EnumDefine_h

typedef NS_ENUM (NSInteger,ZPDynamicMediaType) {
    ZPDynamicMediaType_Text,
    ZPDynamicMediaType_Image,
    ZPDynamicMediaType_Video
};

typedef NS_ENUM (NSInteger,ZPDynamicResultType) {
    ZPDynamicResultType_Index,
    ZPDynamicResultType_Search,
    ZPDynamicResultType_My
};

#endif /* EnumDefine_h */
