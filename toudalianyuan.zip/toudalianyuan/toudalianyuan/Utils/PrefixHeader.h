//
//  PrefixHeader.h
//  toudalianyuan
//
//  Created by Biao Geng on 2019/7/19.
//  Copyright © 2019年 Peng Zhou. All rights reserved.
//

#ifndef PrefixHeader_h
#define PrefixHeader_h

#ifdef __OBJC__
#import <UIKit/UIKit.h>
#import <Foundation/Foundation.h>

//全局宏
#import "ConfigDefine.h"
#import "MacroDefine.h"
#import "EnumDefine.h"

//基础类
#import "AppDelegate.h"
#import "SDAutoLayout.h"
#import "UIImageView+WebCache.h"
#import "UIButton+WebCache.h"
#import "UIBarButtonItem+HPBarButtonItem.h"
#import "MBProgressHUD+Ex.h"
#import "NSString+ZPTimeString.h"
#import "MJRefresh.h"
#import "YYWebImage.h"
#import "MJExtension.h"
#import "ZPNetWorkTool.h"
#import "ZPLoginUserModel.h"
#import "HBDNavigationController.h"
#import "UIViewController+HBD.h"

#ifdef DEBUG
#define ZPLog(...) NSLog(__VA_ARGS__)

#else

#define ZPLog(...)
#endif

#endif
#endif /* PrefixHeader_h */
