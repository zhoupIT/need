//
//  UHTabBarViewController.h
//  Peng Zhou
//
//  Created by 鹏 周 on 2017/8/28.
//  Copyright © 2017年 Peng Zhou. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UHTabBarViewController : UITabBarController

@end
