//
//  RHTabBarViewController.m
//  Peng Zhou
//
//  Created by 鹏 周 on 2017/8/28.
//  Copyright © 2017年 Peng Zhou. All rights reserved.
//

#import "UHTabBarViewController.h"
#import "UHNavigationController.h"
#import "ZPIndexViewController.h"
#import "ZPMeViewController.h"
#import "UHTabBar.h"
#import "ZPNavController.h"

@interface UHTabBarViewController ()<UITabBarControllerDelegate>
@property (nonatomic,strong) UHTabBar *uhtabbar;
@end

@implementation UHTabBarViewController

+ (void)initialize {
    NSDictionary *norAttr = @{
                              NSForegroundColorAttributeName : UIColorFromRGB(0x808a91)
                              };
    NSDictionary *selAttr = @{
                              NSForegroundColorAttributeName : UIColorFromRGB(0x193b6a)
                              };
    [[UITabBarItem appearance] setTitleTextAttributes:norAttr forState:UIControlStateNormal];
    [[UITabBarItem appearance] setTitleTextAttributes:selAttr forState:UIControlStateSelected];
    
    [[UITabBar appearance] setTintColor:[UIColor whiteColor]];
    [[UITabBar appearance] setBarTintColor:[UIColor whiteColor]];
    //设置不透明
    [[UITabBar appearance] setTranslucent:NO];
    
    //去除tabbar上的黑线
    [UITabBar appearance].backgroundImage = [UIImage new];
    [UITabBar appearance].shadowImage = [UIImage new];
}



- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.delegate = self;
    ZPIndexViewController *view1 = [[ZPIndexViewController alloc] init];
    ZPMeViewController *view2 = [[ZPMeViewController alloc] init];

    [self addChildVC:view1 title:@"Dynamics" image:@"ic_home_index" selImage:@"ic_home_indexS"];
    [self addChildVC:view2 title:@"Me" image:@"ic_me_me" selImage:@"ic_me_meS"];

    
    self.selectedIndex = 0;

    
    self.tabBar.layer.shadowColor = [UIColor colorWithRed:0.0f/255.0f green:0.0f/255.0f blue:0.0f/255.0f alpha:0.16f].CGColor;;
    self.tabBar.layer.shadowOffset = CGSizeMake(0, 0);
    self.tabBar.layer.shadowOpacity = 1;
    self.tabBar.layer.shadowRadius = 3;
}

- (void)addChildVC:(UIViewController *)vc title:(NSString *)title image:(NSString *)image selImage:(NSString *)selImage
{
    vc.title = title;
    vc.tabBarItem.image = [[UIImage imageNamed:image] imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
    vc.tabBarItem.selectedImage = [[UIImage imageNamed:selImage] imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
    vc.edgesForExtendedLayout = UIRectEdgeNone;
    ZPNavController *nvc = [[ZPNavController alloc] initWithRootViewController:vc];
    [self addChildViewController:nvc];
}

#pragma mark - UITabBarControllerDelegate
- (BOOL)tabBarController:(UITabBarController *)tabBarController shouldSelectViewController:(UIViewController *)viewController {
        return YES;
}

#pragma mark - UITabBarDelegate
- (void)tabBar:(UITabBar *)tabBar didSelectItem:(UITabBarItem *)item {
}
@end
