//
//  ZPMemberHeaderView
//  toudalianyuan
//
//  Created by Z P on 2019/8/9.
//  Copyright © 2019年 Peng Zhou. All rights reserved.
//

#import "ZPMemberHeaderView.h"

@interface ZPMemberHeaderView()
{
    UILabel *_titleLabel;
    UILabel *_subTitleLabel;
}
@end

@implementation ZPMemberHeaderView
- (instancetype)initWithFrame:(CGRect)frame {
    if (self = [super initWithFrame:frame]) {
        [self initUI];
    }
    return self;
}

- (void)initUI {
    _titleLabel = [UILabel new];
    _subTitleLabel = [UILabel new];
    [self sd_addSubviews:@[_titleLabel,_subTitleLabel]];
    _titleLabel.sd_layout
    .leftSpaceToView(self, 20)
    .bottomEqualToView(self)
    .autoHeightRatio(0);
    [_titleLabel setSingleLineAutoResizeWithMaxWidth:300];
    _titleLabel.text = @"Team Member";
    _titleLabel.textColor = [UIColor blackColor];
    _titleLabel.font = [UIFont fontWithName:ZPPFSCRegular size:17];
    
    _subTitleLabel.sd_layout
    .rightSpaceToView(self, 20)
    .bottomEqualToView(self)
    .autoHeightRatio(0);
    [_subTitleLabel setSingleLineAutoResizeWithMaxWidth:300];
    _subTitleLabel.text = @"See All>>";
    _subTitleLabel.textAlignment = NSTextAlignmentRight;
    _subTitleLabel.textColor = [UIColor grayColor];
    _subTitleLabel.font = [UIFont fontWithName:ZPPFSCRegular size:13];
    _subTitleLabel.userInteractionEnabled = YES;
    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(onSeeAllClicked)];
    [_subTitleLabel addGestureRecognizer:tap];
}

- (void)onSeeAllClicked {
    if (self.onSeeAllBlock) {
        self.onSeeAllBlock();
    }
}
@end
