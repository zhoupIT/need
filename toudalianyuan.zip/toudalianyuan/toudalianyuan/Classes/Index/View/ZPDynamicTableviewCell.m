//
//  ZPDynamicTableviewCell.m
//  toudalianyuan
//
//  Created by Biao Geng on 2019/7/25.
//  Copyright © 2019年 Peng Zhou. All rights reserved.
//

#import "ZPDynamicTableviewCell.h"
#import "ZPDynamicModel.h"
#import "SDWeiXinPhotoContainerView.h"
#import "WMPlayer.h"
@interface ZPDynamicTableviewCell()
{
    UIImageView *_avaIcon;
    UILabel *_nameLabel;
    UILabel *_isOwnerLabel;
    UILabel *_timeLabel;
    UILabel *_descLabel;
    SDWeiXinPhotoContainerView *_picContainer;
    //video
    UIImageView *_videoPreview;
    UIButton *_videoplayBtn;
    UIView *_lineView;
    
    UIButton *_showMoreBtn;
}
@end
@implementation ZPDynamicTableviewCell

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier {
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        [self initUI];
    }
    return self;
}

- (void)initUI {
    self.selectionStyle = UITableViewCellSelectionStyleNone;
    
    _avaIcon = [UIImageView new];
    _nameLabel = [UILabel new];
    _isOwnerLabel = [UILabel new];
    _timeLabel = [UILabel new];
    _descLabel = [UILabel new];
    _picContainer = [[SDWeiXinPhotoContainerView alloc] init];
    _videoBg = [UIView new];
    _videoPreview = [UIImageView new];
    _videoplayBtn = [UIButton new];
    _lineView = [UIView new];
    _showMoreBtn = [UIButton new];
    [self.contentView sd_addSubviews:@[_avaIcon,_nameLabel,_isOwnerLabel,_timeLabel,_descLabel,_picContainer,_videoBg,_lineView,_showMoreBtn]];
    _avaIcon.sd_layout
    .leftSpaceToView(self.contentView, 20)
    .topSpaceToView(self.contentView, 20)
    .widthIs(50)
    .heightIs(50);
    
    _nameLabel.sd_layout
    .leftSpaceToView(_avaIcon, 10)
    .topEqualToView(_avaIcon)
    .autoHeightRatio(0);
    [_nameLabel setSingleLineAutoResizeWithMaxWidth:200];
    _nameLabel.textColor = UIColorFromRGB(0x000000);
    _nameLabel.font = [UIFont fontWithName:ZPPFSCRegular size:16];
    
    _isOwnerLabel.sd_layout
    .leftSpaceToView(_nameLabel, 10)
    .widthIs(25)
    .heightIs(25)
    .centerYEqualToView(_nameLabel);
    _isOwnerLabel.backgroundColor = UIColorFromRGB(0xfef2ce);
    _isOwnerLabel.textColor = UIColorFromRGB(0x666666);
    _isOwnerLabel.font = [UIFont fontWithName:ZPPFSCLight size:10];
    _isOwnerLabel.sd_cornerRadius = @12.5;
    _isOwnerLabel.textAlignment = NSTextAlignmentCenter;
    _isOwnerLabel.text = @"Me";
    
    _showMoreBtn.sd_layout
    .rightSpaceToView(self.contentView, 10)
    .topSpaceToView(self.contentView, 10)
    .widthIs(16)
    .heightIs(16);
    [_showMoreBtn setBackgroundImage:[UIImage imageNamed:@"ic_index_showMore"] forState:UIControlStateNormal];
    [_showMoreBtn addTarget:self action:@selector(onShowMoreBtnClicked) forControlEvents:UIControlEventTouchUpInside];
    
    
    _timeLabel.sd_layout
    .topSpaceToView(_nameLabel, 5)
    .leftSpaceToView(_avaIcon, 10)
    .rightSpaceToView(self.contentView, 20)
    .autoHeightRatio(0);
    _timeLabel.textColor =UIColorFromRGB(0x999999);
    _timeLabel.font = [UIFont fontWithName:ZPPFSCRegular size:14];
    
    _descLabel.sd_layout
    .topSpaceToView(_timeLabel, 10)
    .leftSpaceToView(_avaIcon, 10)
    .rightSpaceToView(self.contentView, 20)
    .autoHeightRatio(0);
    _descLabel.textColor = UIColorFromRGB(0x4c4c4c);
    _descLabel.font = [UIFont fontWithName:ZPPFSCRegular size:16];
    
    _picContainer.sd_layout.leftSpaceToView(self.contentView,80);
    
    _videoBg.backgroundColor = [UIColor blackColor];
    _videoBg.sd_layout
    .leftSpaceToView(self.contentView,80)
    .rightSpaceToView(self.contentView, 20)
    .heightIs(0)
    .topSpaceToView(_descLabel, 10);
    [_videoBg sd_addSubviews:@[_videoPreview,_videoplayBtn]];
    _videoPreview.sd_layout
    .topEqualToView(_videoBg)
    .bottomEqualToView(_videoBg)
    .widthIs(100)
    .centerXEqualToView(_videoBg);
    _videoPreview.userInteractionEnabled = YES;
    _videoplayBtn.sd_layout
    .centerXEqualToView(_videoBg)
    .centerYEqualToView(_videoBg)
    .heightIs(50)
    .widthIs(50);
    [_videoplayBtn setImage:[UIImage imageNamed:@"video_play_btn_bg"] forState:UIControlStateNormal];
    [_videoplayBtn addTarget:self action:@selector(onPlayClicked) forControlEvents:UIControlEventTouchUpInside];
    
    _lineView.backgroundColor = RGB(241, 241, 241);
}

- (void)setDynamicModel:(ZPDynamicModel *)dynamicModel {
    _dynamicModel = dynamicModel;
    [_avaIcon sd_setImageWithURL:[NSURL URLWithString:dynamicModel.portrait]];
    _nameLabel.text = dynamicModel.nickname;
    NSString *createdAt = dynamicModel.createDate;
    _timeLabel.text = [NSString compareCurrentTime:createdAt];
    _descLabel.text = dynamicModel.shareMsg;
    if (![kUSER_DEFAULT objectForKey:@"ownID"]) {
        //hidden
        _isOwnerLabel.hidden = YES;
    } else {
        if (![[kUSER_DEFAULT objectForKey:@"ownID"] isEqualToString:dynamicModel.userId]) {
            _isOwnerLabel.hidden = YES;
        } else {
            _isOwnerLabel.hidden = NO;
        }
    }
    if (dynamicModel.video.length) {
        _videoBg.hidden = NO;
        _videoBg.sd_layout.heightIs(150);
        [_videoPreview sd_setImageWithURL:[NSURL URLWithString:@"https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1566300104852&di=1cf8eaaaa6f465a6bdf524e29035b32e&imgtype=0&src=http%3A%2F%2Fpic39.nipic.com%2F20140321%2F18063302_210604412116_2.jpg"]];
        _lineView.sd_layout
        .leftSpaceToView(self.contentView, 0)
        .rightSpaceToView(self.contentView, 0)
        .heightIs(1)
        .topSpaceToView(_videoBg, 10);
    } else {
        _videoBg.hidden = YES;
        _videoBg.sd_layout.heightIs(0);
        _picContainer.picPathStringsArray = dynamicModel.imgList;
        CGFloat picContainerTopMargin = 0;
        if ([dynamicModel.imgList count]) {
            picContainerTopMargin = 10;
        }
        _picContainer.sd_layout.topSpaceToView(_descLabel, picContainerTopMargin);
        
        _lineView.sd_layout
        .leftSpaceToView(self.contentView, 0)
        .rightSpaceToView(self.contentView, 0)
        .heightIs(1)
        .topSpaceToView(_picContainer, 10);
    }
    
     [self setupAutoHeightWithBottomViewsArray:@[_lineView] bottomMargin:0];
}

- (void)setDynamicResultType:(ZPDynamicResultType)dynamicResultType {
    _dynamicResultType = dynamicResultType;
    switch (dynamicResultType) {
        case ZPDynamicResultType_My:
        {
            _isOwnerLabel.hidden = YES;
        }
            break;
            
            
        default:
            break;
    }
}

- (void)onPlayClicked {
    if (self.onPlayClickedBlock) {
        self.onPlayClickedBlock(_videoBg,self.dynamicModel);
    }
}

- (void)onShowMoreBtnClicked {
    if (self.onShowMoreBlock) {
        self.onShowMoreBlock(self.dynamicModel);
    }
}
@end
