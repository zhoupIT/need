//
//  ZPMemberTableViewCell.h
//  toudalianyuan
//
//  Created by Z P on 2019/8/9.
//  Copyright © 2019年 Peng Zhou. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface ZPMemberTableViewCell : UITableViewCell
@property (nonatomic,strong) ZPLoginUserModel *model;
@end

NS_ASSUME_NONNULL_END
