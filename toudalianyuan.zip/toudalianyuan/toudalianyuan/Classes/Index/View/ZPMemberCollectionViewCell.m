//
//  ZPDynamicCollectionViewCell.m
//  toudalianyuan
//
//  Created by Biao Geng on 2019/7/24.
//  Copyright © 2019年 Peng Zhou. All rights reserved.
//

#import "ZPMemberCollectionViewCell.h"

@interface ZPMemberCollectionViewCell()
{
    UIImageView *_avaIconView;
    UILabel *_nameLabel;
    UILabel *_levelLabel;
    UILabel *_descLabel;
}
@end

@implementation ZPMemberCollectionViewCell
- (instancetype)initWithFrame:(CGRect)frame {
    if (self = [super initWithFrame:frame]) {
        [self initUI];
    }
    return self;
}

- (void)initUI {
    self.contentView.layer.cornerRadius = 10;
    self.contentView.layer.masksToBounds = YES;
    self.contentView.backgroundColor = [UIColor whiteColor];
    _avaIconView = [UIImageView new];
    _nameLabel = [UILabel new];
    _levelLabel = [UILabel new];
    _descLabel = [UILabel new];
    
    UIImageView *bg = [UIImageView new];
    [bg sd_setImageWithURL:[NSURL URLWithString:@"https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1562914190944&di=9e8c847a7a763ca99fd67fee14d30e00&imgtype=0&src=http%3A%2F%2Fhbimg.b0.upaiyun.com%2Ff51c8d6caf9400853ca2d38600df7b366963f4c666cc0-yybPWw_fw658"]];
    [self.contentView addSubview:bg];
    bg.sd_layout.spaceToSuperView(UIEdgeInsetsZero);
    
    [bg sd_addSubviews:@[_avaIconView,_nameLabel,_levelLabel,_descLabel]];
    _avaIconView.sd_layout
    .leftSpaceToView(bg, 10)
    .topSpaceToView(bg, 30)
    .widthIs(50)
    .heightIs(50);
    _avaIconView.sd_cornerRadius = @25;
    
    _nameLabel.sd_layout
    .leftSpaceToView(_avaIconView, 10)
    .topEqualToView(_avaIconView)
    .rightSpaceToView(bg, 10)
    .autoHeightRatio(0);
    [_nameLabel setMaxNumberOfLinesToShow:1];
    _nameLabel.textColor = [UIColor whiteColor];
    _nameLabel.font = [UIFont fontWithName:ZPPFSCRegular size:14];
    _nameLabel.text = @"";
    
    _levelLabel.sd_layout
    .leftSpaceToView(_avaIconView, 10)
    .topSpaceToView(_nameLabel, 5)
    .rightSpaceToView(bg, 10)
    .autoHeightRatio(0);
    [_levelLabel setMaxNumberOfLinesToShow:1];
    _levelLabel.textColor = UIColorFromRGB(0x999999);
    _levelLabel.font = [UIFont fontWithName:ZPPFSCRegular size:12];
    _levelLabel.text = @"";
    
    _descLabel.sd_layout
    .leftSpaceToView(bg, 5)
    .topSpaceToView(_avaIconView, 15)
    .rightSpaceToView(bg, 5)
    .autoHeightRatio(0);
    [_descLabel setMaxNumberOfLinesToShow:1];
    _descLabel.textColor = [UIColor whiteColor];
    _descLabel.font = [UIFont fontWithName:ZPPFSCMedium size:18];
    _descLabel.textAlignment = NSTextAlignmentCenter;
    _descLabel.text = @"";
}

- (void)setModel:(ZPLoginUserModel *)model {
    _model = model;
    _nameLabel.text = model.nickname;
    _descLabel.text = [NSString stringWithFormat:@"\"%@\"",model.declaration];
    [_avaIconView sd_setImageWithURL:[NSURL URLWithString:model.portrait]];
     _levelLabel.text = [NSString stringWithFormat:@"Level:%@",model.customerLevel];
}
@end
