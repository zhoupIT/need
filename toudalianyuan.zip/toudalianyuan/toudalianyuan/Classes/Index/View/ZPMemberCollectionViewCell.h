//
//  ZPDynamicCollectionViewCell.h
//  toudalianyuan
//
//  Created by Biao Geng on 2019/7/24.
//  Copyright © 2019年 Peng Zhou. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN
@interface ZPMemberCollectionViewCell : UICollectionViewCell
@property (nonatomic,strong) ZPLoginUserModel *model;
@end

NS_ASSUME_NONNULL_END
