//
//  ZPDynamicTableviewCell.h
//  toudalianyuan
//
//  Created by Biao Geng on 2019/7/25.
//  Copyright © 2019年 Peng Zhou. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ZPDynamicModel.h"
NS_ASSUME_NONNULL_BEGIN

@interface ZPDynamicTableviewCell : UITableViewCell
@property (nonatomic,assign) ZPDynamicResultType dynamicResultType;
@property (nonatomic,strong) ZPDynamicModel *dynamicModel;
@property (nonatomic,copy) void (^onShowMoreBlock) (ZPDynamicModel *dynamicModel);
@property (nonatomic,copy) void (^onPlayClickedBlock) (UIView *previewBg,ZPDynamicModel *dynamicModel);
@property (nonatomic,strong) UIView *videoBg;
@end

NS_ASSUME_NONNULL_END
