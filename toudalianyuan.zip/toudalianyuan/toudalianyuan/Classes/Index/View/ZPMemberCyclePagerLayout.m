//
//  ZPCyclePagerLayout.m
//  toudalianyuan
//
//  Created by Biao Geng on 2019/7/23.
//  Copyright © 2019年 Peng Zhou. All rights reserved.
//

#import "ZPMemberCyclePagerLayout.h"

@implementation ZPMemberCyclePagerLayout

/*
 1.首次布局和之后重新布局的时候会调用，并不会每次滑动都调用
 2.当数据源变化时也会调用
 3.自动调用
 */
- (void)prepareLayout {
    [super prepareLayout];
    // 水平滚动
    self.scrollDirection = UICollectionViewScrollDirectionHorizontal;
//    // 决定第一张图片所在的位置
//    CGFloat margin = (self.collectionView.frame.size.width - self.itemSize.width) / 2;
//    NSLog(@"%f",margin);
//    //左边 右边 再增加margin宽度
//    self.collectionView.contentInset = UIEdgeInsetsMake(0, margin, 0, margin);
}

/*
 - 作用：
 
 - 这个方法的返回值是个数组
 
 - 这个数组中存放的都是UICollectionViewLayoutAttributes对象
 
 - UICollectionViewLayoutAttributes对象决定了cell的排布方式（frame等）
 
 - 让cell在左右滑动的时候，尺寸放大或缩小
 */
- (NSArray<UICollectionViewLayoutAttributes *> *)layoutAttributesForElementsInRect:(CGRect)rect {
    // 闪屏现象解决参考 ：https://blog.csdn.net/u013282507/article/details/53103816
    //扩大控制范围，防止出现闪屏现象
//    rect.size.width = rect.size.width + SCREEN_WIDTH;
//    rect.origin.x = rect.origin.x - SCREEN_WIDTH/2;
    
    // 让父类布局好样式
    NSArray *arr = [[NSArray alloc] initWithArray:[super layoutAttributesForElementsInRect:rect] copyItems:YES];
    
    //collectionView 的 centerX
    CGFloat centerX = self.collectionView.center.x;
    for (UICollectionViewLayoutAttributes *attributes in arr) {
        CGFloat scale;
        //        scale = 1.0;
        
        //ABS整数绝对值
        //self.collectionView.center.x 这是固定的值 collectionView
        //self.collectionView.contentOffset.x 这是内容最左侧相对于 collectionView 最左侧的偏移值
        //attributes.center.x ：这是当前 item 的水平中心点，该 x 值是从内容的最左侧算起，直到当前 item 的水平中心点的，全部加起来就是该 item 的水平中心 x。
        CGFloat step = ABS(centerX - (attributes.center.x - self.collectionView.contentOffset.x));
//        NSLog(@"step %@ :centerX-( attX %@ - offset %@)", @(step), @(attributes.center.x), @(self.collectionView.contentOffset.x));
        //cosf求余弦值  fabsf浮点数绝对值 M_PI代表pi(π)
        scale = fabsf(cosf(step/centerX * M_PI/5));
//        NSLog(@"---------------------->scale:  %@ ", @(scale));
        //CGAffineTransformMakeScale两个参数代表x和y方向缩放倍数
        if (scale < 0.8) {
            scale = 0.8;
        }
        attributes.transform = CGAffineTransformMakeScale(1, scale);
//        if (attributes.indexPath.length > 0) {
//            attributes.transform = CGAffineTransformMakeScale(1, 0.8);
//        }
    }
    
    return arr;
}

/*
 - 作用：如果返回YES，那么collectionView显示的范围发生改变时，就会重新刷新布局
 
 - 一旦重新刷新布局，就会按顺序调用下面的方法：
 
 - prepareLayout
 
 - layoutAttributesForElementsInRect:
 */
-(BOOL)shouldInvalidateLayoutForBoundsChange:(CGRect)newBounds
{
    return YES;
}


/*
 
 - 这个方法的返回值，就决定了collectionView停止滚动时的偏移量
 
 - 让最接近中心的cell在停在正中央
 */
- (CGPoint)targetContentOffsetForProposedContentOffset:(CGPoint)proposedContentOffset withScrollingVelocity:(CGPoint)velocity {
    
    // 保证滚动结束后视图的显示效果
    
    // 计算出最终显示的矩形框
    CGRect rect;
    rect.origin.y = 0;
    rect.origin.x = proposedContentOffset.x;
    rect.size = self.collectionView.frame.size;
    
    // 获得 super 已经计算好的布局的属性
    NSArray *arr = [super layoutAttributesForElementsInRect:rect];
    
    // 计算 collectionView 最中心点的 x 值
    CGFloat centerX = proposedContentOffset.x + self.collectionView.frame.size.width * 0.5;
    
    CGFloat minDelta = MAXFLOAT;
    for (UICollectionViewLayoutAttributes *attrs in arr) {
        if (ABS(minDelta) > ABS(attrs.center.x - centerX)) {
            minDelta = attrs.center.x - centerX;
        }
    }
    
    proposedContentOffset.x += minDelta;
    return proposedContentOffset;
}
@end
