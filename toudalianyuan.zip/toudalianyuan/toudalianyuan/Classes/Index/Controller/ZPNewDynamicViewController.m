//
//  ZPNewDynamicViewController.m
//  toudalianyuan
//
//  Created by Biao Geng on 2019/7/26.
//  Copyright © 2019年 Peng Zhou. All rights reserved.
//

#import "ZPNewDynamicViewController.h"
#import "ZPTextView.h"
#import "TZImagePickerController.h"
#import "YYText.h"
#import "WMPlayer.h"
#import "ZPNetWork.h"

#define kToolbarHeight 46
@interface ZPNewDynamicViewController ()<TZImagePickerControllerDelegate,YYTextKeyboardObserver,YYTextViewDelegate,WMPlayerDelegate,UIScrollViewDelegate>

@property (nonatomic,strong) UIScrollView *scrollView;
@property (nonatomic, strong) ZPTextView *textView;
@property (nonatomic,strong) WMPlayer *player;
@property (nonatomic,strong) UIImageView *coverImg;
@property (nonatomic,strong) UIButton *playBtn;
@property (nonatomic,strong) UIButton *closeBtn;
@property (nonatomic, strong) UIView *toolbar;
@property (nonatomic, strong) UIView *toolbarBackground;
@property (nonatomic, strong) UIButton *toolbarPictureButton;
@property (nonatomic, strong) UIButton *toolbarVideoButton;
@property (nonatomic,strong) UIView *ImgView;

@property (nonatomic,strong) NSURL *videoUrl;
@property (nonatomic,strong) NSMutableArray *imgArray;
@property (nonatomic,strong) NSMutableArray *phArray;
@property (nonatomic,strong) NSMutableArray *phdataArray;
//post
@property (nonatomic,strong) NSString *video;
@end

@implementation ZPNewDynamicViewController

- (instancetype)init {
    self = [super init];
    [[YYTextKeyboardManager defaultManager] addObserver:self];
    return self;
}

- (void)dealloc {
    [[YYTextKeyboardManager defaultManager] removeObserver:self];
}

- (void)viewDidLoad {
    [super viewDidLoad];
    [self initUI];
}

- (void)initUI {
    self.title = @"New dynamic";
    self.view.backgroundColor = [UIColor whiteColor];
    self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc] initWithTitle:@"Publish" style:UIBarButtonItemStyleDone target:self action:@selector(onPublishClicked)];
    
    [self.view addSubview:self.scrollView];
    self.scrollView.sd_layout.spaceToSuperView(UIEdgeInsetsZero);
    [self initTextView];
    [self initToolbar];
    [self initPlayer];
}

- (void)initTextView {
    [self.scrollView addSubview:self.textView];
}

- (void)initToolbar {
    [self.view addSubview:self.toolbar];
}

- (UIButton *)_toolbarButtonWithImage:(NSString *)imageName highlight:(NSString *)highlightImageName {
    UIButton *button = [UIButton buttonWithType:UIButtonTypeCustom];
    button.exclusiveTouch = YES;
    button.size = CGSizeMake(46, 46);
    [button setImage:[UIImage imageNamed:imageName] forState:UIControlStateNormal];
    [button setImage:[UIImage imageNamed:highlightImageName] forState:UIControlStateHighlighted];
    button.centerY = 46 / 2;
    button.autoresizingMask = UIViewAutoresizingFlexibleLeftMargin | UIViewAutoresizingFlexibleRightMargin;
    [button addTarget:self action:@selector(_buttonClicked:) forControlEvents:UIControlEventTouchUpInside];
    [_toolbarBackground addSubview:button];
    return button;
}

- (void)initPlayer {
    //video
    self.coverImg = [UIImageView new];
    self.coverImg.contentMode = UIViewContentModeScaleAspectFit;
    [self.scrollView addSubview:self.coverImg];
    self.coverImg.userInteractionEnabled = YES;
    self.coverImg.sd_layout
    .topSpaceToView(_textView, 10)
    .leftSpaceToView(self.scrollView, 16);
    
    [self.coverImg sd_addSubviews:@[self.playBtn,self.closeBtn]];
    self.playBtn.sd_layout.
    centerXEqualToView(self.coverImg)
    .centerYEqualToView(self.coverImg)
    .widthIs(50)
    .heightIs(50);
    
    self.closeBtn.sd_layout
    .topSpaceToView(self.coverImg, 5)
    .rightSpaceToView(self.coverImg, 5)
    .widthIs(15)
    .heightIs(15);
    
    self.coverImg.hidden = YES;
    //image nine pic
    self.ImgView = [[UIView alloc] init];
    [self.scrollView addSubview:self.ImgView];
    self.ImgView.sd_layout
    .leftEqualToView(self.scrollView)
    .rightEqualToView(self.scrollView)
    .topSpaceToView(_textView, 10);
    
    [self.scrollView setupAutoContentSizeWithBottomView:self.ImgView bottomMargin:10];
}



#pragma mark @protocol YYTextKeyboardObserver
- (void)keyboardChangedWithTransition:(YYTextKeyboardTransition)transition {
    CGRect toFrame = [[YYTextKeyboardManager defaultManager] convertRect:transition.toFrame toView:self.view];
    if (transition.animationDuration == 0) {
        _toolbar.bottom = CGRectGetMinY(toFrame);
    } else {
        [UIView animateWithDuration:transition.animationDuration delay:0 options:transition.animationOption | UIViewAnimationOptionBeginFromCurrentState animations:^{
            _toolbar.bottom = CGRectGetMinY(toFrame);
        } completion:NULL];
    }
}

#pragma mark - private
- (void)addImgWithNum:(NSInteger)index withTotal:(NSInteger)total withPhoto:(UIImage *)showimage {
    //一行的列数
    NSInteger cols = 3;
    CGFloat margin = 16;
    //每一列的间距
    CGFloat colMargin = 10;
    //图片大小
    NSInteger imageW = (SCREEN_WIDTH-margin*2-colMargin*2)/cols;
    NSInteger imageH = (SCREEN_WIDTH-margin*2-colMargin*2)/cols;
    //图片所在列
    NSInteger col = index % cols;
    //图片所在行
    NSInteger row = index / cols;
    CGFloat shopX = col * (imageW +colMargin);
    CGFloat shopY = row * (imageH + colMargin);
    YYAnimatedImageView *imageView = [[YYAnimatedImageView alloc] initWithImage:showimage];
    imageView.frame = CGRectMake(shopX+margin, shopY, imageW, imageH);
    imageView.backgroundColor = [UIColor redColor];
//    imageView.image = showimage;
    imageView.userInteractionEnabled = YES;
    [self.ImgView addSubview:imageView];
    UIButton *delBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    delBtn.tag = index;
    [delBtn setImage:[UIImage imageNamed:@"ic_report_delete"] forState:UIControlStateNormal];
    [delBtn addTarget:self action:@selector(onDelImgClicked:) forControlEvents:UIControlEventTouchUpInside];
    [imageView addSubview:delBtn];
    delBtn.sd_layout
    .rightSpaceToView(imageView, 5)
    .topSpaceToView(imageView, 5)
    .widthIs(15)
    .heightIs(15);
    
    if (total == (index+1)) {
        [self.ImgView setupAutoHeightWithBottomView:imageView bottomMargin:0];
    }
}

- (void)onDelImgClicked:(UIButton *)btn {
    [self.imgArray removeObjectAtIndex:btn.tag];
    [self.phArray removeObjectAtIndex:btn.tag];
    [self.phdataArray removeObjectAtIndex:btn.tag];
    for (UIView *subView in self.ImgView.subviews) {
        [subView removeFromSuperview];
    }
    for (NSInteger i = 0; i<self.imgArray.count; i++) {
        [self addImgWithNum:i withTotal:self.imgArray.count withPhoto:self.imgArray[i]];
    }
}

- (void)_buttonClicked:(UIButton *)btn {
    if (btn == _toolbarPictureButton) {
        [self onUploadImgClicked];
    } else if (btn == _toolbarVideoButton) {
        [self onUploadVideoClicked];
    }
}

- (void)onPublishClicked {
    [self.view endEditing:YES];
    if (self.textView.text.length >= 5 ) {
        ZPLog(@"publish");
        if (self.phdataArray.count) {
            //upload img
            WEAK_SELF(weakSelf);
            [MBProgressHUD showMessage:@"Loading"];
            NSMutableArray *imgList = [NSMutableArray new];
            dispatch_group_t group = dispatch_group_create();
            int i = 0;
            for (PHAsset *asset in self.phArray) {
                dispatch_group_enter(group);
                NSString *filename = [asset valueForKey:@"filename"];
                NSData *data;
                if ([[filename lowercaseString] containsString:@".gif"]) {
                    data = [self.phdataArray[i] objectForKey:@"scale_image"];
                } else {
                    data  = UIImageJPEGRepresentation(self.imgArray[i],0.0);
                }
                [[ZPNetWorkTool sharedZPNetWorkTool] POSTRequestWith:@"upload" parameters:nil constructingBodyWithBlock:^(id<AFMultipartFormData> formData) {
                    NSString *filename = [asset valueForKey:@"filename"];
                    if ([[filename lowercaseString] containsString:@".gif"]) {
                        [formData appendPartWithFileData:data name:@"file" fileName:filename mimeType:@"gif"];
                    } else {
                        [formData appendPartWithFileData:data name:@"file" fileName:filename mimeType:@"png"];
                    }
                } progress:^(NSProgress *progress) {
                    
                } success:^(NSURLSessionDataTask *task, id response) {
                    dispatch_group_leave(group);
                    [imgList addObject:[response objectForKey:@"data"]];
                } failed:^(NSURLSessionDataTask *task, NSError *error) {
                    dispatch_group_leave(group);
                } className:[ZPNewDynamicViewController class]];
                i++;
            }
            dispatch_group_notify(group, dispatch_get_main_queue(), ^{
                NSLog(@"全部上传成功");
               
                [[ZPNetWork sharedZPNetWork] requestWithUrl:@"api/share" andHTTPMethod:@"PUT" andDict:@{@"imgList":imgList,@"shareMsg":self.textView.text} success:^(NSDictionary *response) {
                     [MBProgressHUD hideHUD];
                    if ([[response objectForKey:@"code"] integerValue]  == 200) {
                        [MBProgressHUD showSuccess:@"Publish Success!"];
                        if (weakSelf.updateDynamicsBlock) {
                            weakSelf.updateDynamicsBlock();
                        }
                        [weakSelf.navigationController popViewControllerAnimated:YES];
                    }
                } failed:^(NSError *error) {
                     [MBProgressHUD hideHUD];
                }];
            });
        } else if (self.videoUrl.absoluteString.length) {
            WEAK_SELF(weakSelf);
            //upload video
            [MBProgressHUD showMessage:@"Loading"];
            NSData *data = [NSData dataWithContentsOfURL:self.videoUrl];
            [[ZPNetWorkTool sharedZPNetWorkTool] POSTRequestWith:@"upload" parameters:nil constructingBodyWithBlock:^(id<AFMultipartFormData> formData) {
                NSDate *date = [NSDate date];
                NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
                [dateFormatter setDateFormat:@"yyyy-MM-ddHH:mm:ss"];
                NSString *strDate = [dateFormatter stringFromDate:date];
                NSString *filename = [NSString stringWithFormat:@"%@.mp4",strDate];
                [formData appendPartWithFileData:data name:@"file" fileName:filename mimeType:@"mp4"];
            } progress:^(NSProgress *progress) {
                
            } success:^(NSURLSessionDataTask *task, id response) {
                [[ZPNetWork sharedZPNetWork] requestWithUrl:@"api/share" andHTTPMethod:@"PUT" andDict:@{@"video":[response objectForKey:@"data"],@"shareMsg":self.textView.text} success:^(NSDictionary *response) {
                    [MBProgressHUD hideHUD];
                    if ([[response objectForKey:@"code"] integerValue]  == 200) {
                        [MBProgressHUD showSuccess:@"Publish Success!"];
                        if (weakSelf.updateDynamicsBlock) {
                            weakSelf.updateDynamicsBlock();
                        }
                        [weakSelf.navigationController popViewControllerAnimated:YES];
                    }
                } failed:^(NSError *error) {
                    [MBProgressHUD hideHUD];
                }];
            } failed:^(NSURLSessionDataTask *task, NSError *error) {
                [MBProgressHUD hideHUD];
            } className:[ZPNewDynamicViewController class]];
        } else {
            //upload text
             WEAK_SELF(weakSelf);
            [MBProgressHUD showMessage:@"Loading..."];
            [[ZPNetWork sharedZPNetWork] requestWithUrl:@"api/share" andHTTPMethod:@"PUT" andDict:@{@"shareMsg":self.textView.text} success:^(NSDictionary *response) {
                [MBProgressHUD hideHUD];
                if ([[response objectForKey:@"code"] integerValue]  == 200) {
                    [MBProgressHUD showSuccess:@"Publish Success!"];
                    if (weakSelf.updateDynamicsBlock) {
                        weakSelf.updateDynamicsBlock();
                    }
                    [weakSelf.navigationController popViewControllerAnimated:YES];
                }
            } failed:^(NSError *error) {
                [MBProgressHUD hideHUD];
            }];
        }
    } else {
        ZPLog(@"alert");
        [MBProgressHUD showError:@"Please input more than 5 words!"];
        
    }
}

/*
 *  upload video
 */
- (void)onUploadVideoClicked {
    if (self.phdataArray.count) {
        [MBProgressHUD showError:@"Photos and videos can only be uploaded one type!"];
        return;
    }
    WEAK_SELF(weakSelf);
    TZImagePickerController *imagePickerVc = [[TZImagePickerController alloc] initWithMaxImagesCount:0 delegate:self];
    imagePickerVc.allowPickingVideo = YES;
    imagePickerVc.allowPickingGif = NO;
    imagePickerVc.allowPickingImage = NO;
    imagePickerVc.preferredLanguage = @"en";
    [imagePickerVc setDidFinishPickingVideoHandle:^(UIImage *coverImage, PHAsset *asset) {
        if (asset.mediaType == PHAssetMediaTypeVideo) {
            dispatch_async(dispatch_get_main_queue(), ^{
                weakSelf.coverImg.hidden = NO;
                CGFloat width = asset.pixelWidth;
                CGFloat height = asset.pixelHeight;
                CGFloat targetWidth = (asset.pixelHeight > asset.pixelWidth)?(SCREEN_WIDTH*0.5):(SCREEN_WIDTH -52);
                CGFloat targetHeight = targetWidth / (width / height);
                weakSelf.coverImg.sd_layout
                .heightIs(targetHeight)
                .widthIs(targetWidth);
                weakSelf.coverImg.image = coverImage;
                [weakSelf.view bringSubviewToFront:weakSelf.toolbar];
                
            });
            //get videourl from PHAsset
            PHVideoRequestOptions *options = [[PHVideoRequestOptions alloc] init];
            options.version = PHImageRequestOptionsVersionCurrent;
            options.deliveryMode = PHVideoRequestOptionsDeliveryModeFastFormat;
            PHImageManager *manager = [PHImageManager defaultManager];
            [manager requestAVAssetForVideo:asset options:options resultHandler:^(AVAsset * _Nullable asset, AVAudioMix * _Nullable audioMix, NSDictionary * _Nullable info) {
                AVURLAsset *urlAsset = (AVURLAsset *)asset;
                NSURL *url = urlAsset.URL;
                dispatch_async(dispatch_get_main_queue(), ^{
                    weakSelf.videoUrl = url;
                });
                NSLog(@"%@",url);
            }];
            
        }
    }];
    [self presentViewController:imagePickerVc animated:YES completion:nil];
}

/*
 *  upload img
 */
- (void)onUploadImgClicked {
    if (self.videoUrl.absoluteString.length) {
        [MBProgressHUD showError:@"Photos and videos can only be uploaded one type!"];
        return;
    }
    WEAK_SELF(weakSelf);
    TZImagePickerController *imagePickerVc = [[TZImagePickerController alloc] initWithMaxImagesCount:9 delegate:self];
    imagePickerVc.allowPickingMultipleVideo = YES;
    imagePickerVc.allowPickingVideo = NO;
    imagePickerVc.allowPickingGif = YES;
    imagePickerVc.preferredLanguage = @"en";
    [imagePickerVc setDidFinishPickingPhotosHandle:^(NSArray<UIImage *> *photos, NSArray *assets, BOOL isSelectOriginalPhoto) {
        NSLog(@"%@",photos);
        if (photos.count) {
            weakSelf.imgArray = [NSMutableArray arrayWithArray:photos];
            weakSelf.phArray = [NSMutableArray arrayWithArray:assets];
            for (NSInteger i = 0; i<photos.count; i++) {
                [weakSelf addImgWithNum:i withTotal:photos.count withPhoto:photos[i]];
            }
        }
        // 如果系统版本大于iOS8，asset是PHAsset类的对象，否则是ALAsset类的对象
        
        __block NSMutableArray *datas = [[NSMutableArray alloc] init];
        [assets enumerateObjectsUsingBlock:^(PHAsset *asset, NSUInteger index, BOOL *innerStop) {
            
            if (asset) {

                UIImage *thumbnail = photos[index];
                NSMutableDictionary *data = [NSMutableDictionary dictionaryWithDictionary:@{ @"type":@"album", @"thumb":thumbnail, @"isUploaded" : @"0"}];
                NSArray *resourceList = [PHAssetResource assetResourcesForAsset:asset];
                
                [resourceList enumerateObjectsUsingBlock:^(id  _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
                    PHAssetResource *resource = obj;
                    PHAssetResourceRequestOptions *option = [[PHAssetResourceRequestOptions alloc]init];
                    option.networkAccessAllowed = YES;
                    
                    // 首先,需要获取沙盒路径
                    
                    NSString *path = [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) lastObject];
                    // 拼接图片名为resource.originalFilename的路径
                    NSString *imageFilePath = [path stringByAppendingPathComponent:resource.originalFilename];
                    [data setValue:imageFilePath forKey:@"path"];
                    if ([resource.uniformTypeIdentifier isEqualToString:@"com.compuserve.gif"]) {
                        NSLog(@"为gif");
                        __block NSData *datagif = [[NSData alloc]init];
                        
                        [[PHAssetResourceManager defaultManager] writeDataForAssetResource:resource toFile:[NSURL fileURLWithPath:imageFilePath]  options:option completionHandler:^(NSError * _Nullable error) {
                            if (error) {
                                if(error.code == -1){//文件已存在
                                    datagif = [NSData dataWithContentsOfURL:[NSURL fileURLWithPath:imageFilePath]];
                                }
                                [data setValue:datagif forKey:@"scale_image"];
                                [data setValue:@1 forKey:@"is_gif"];
                            } else {
                                datagif = [NSData dataWithContentsOfURL:[NSURL fileURLWithPath:imageFilePath]];
                                [data setValue:datagif forKey:@"scale_image"];
                                [data setValue:@1 forKey:@"is_gif"];
                            }
                        }];
                        
                    }else{
                        
                        NSLog(@"jepg");
                        
                        UIImage *originalImage = photos[index];
                        
                        [data setValue:originalImage forKey:@"scale_image"];
                        
                    }
                    
                    [datas addObject:data];
                    
                }];
                
            }
            
        }];
        
        
        
        if ([datas count] > 0) {
            
            self.phdataArray = [NSMutableArray arrayWithArray:datas];
            
        }
    }];
    [self presentViewController:imagePickerVc animated:YES completion:nil];
}

- (void)onVideoPlayClicked {
    if (self.videoUrl.absoluteString.length) {
        [self releaseWMPlayer];
        WMPlayerModel *playerModel = [WMPlayerModel new];
        playerModel.videoURL = self.videoUrl;
        self.player = [[WMPlayer alloc] init];
        self.player.delegate = self;
        self.player.playerModel = playerModel;
        [self.coverImg addSubview:self.player];
        
        self.player.sd_layout.spaceToSuperView(UIEdgeInsetsZero);
        [self.player play];
    }
    
}

- (void)releaseWMPlayer{
    [self.player pause];
    [self.player removeFromSuperview];
    self.player = nil;
}

- (void)onVideoCloseClicked {
    self.videoUrl = nil;
    self.coverImg.sd_layout.heightIs(0).widthIs(0);
    self.coverImg.hidden = YES;
    [self releaseWMPlayer];
}

#pragma mark - delegate
//点击关闭按钮代理方法
-(void)wmplayer:(WMPlayer *)wmplayer clickedCloseButton:(UIButton *)backBtn {
    self.videoUrl = nil;
    self.coverImg.sd_layout.heightIs(0).widthIs(0);
    self.coverImg.hidden = YES;
    [self releaseWMPlayer];
}


//点击全屏按钮代理方法
-(void)wmplayer:(WMPlayer *)wmplayer clickedFullScreenButton:(UIButton *)fullScreenBtn {
    if (self.player.isFullscreen) {//全屏
        //强制翻转屏幕，Home键在下边。
        [[UIDevice currentDevice] setValue:@(UIInterfaceOrientationPortrait) forKey:@"orientation"];
    }else{//非全屏
        [[UIDevice currentDevice] setValue:@(UIInterfaceOrientationLandscapeRight) forKey:@"orientation"];
    }
    //刷新
    [UIViewController attemptRotationToDeviceOrientation];
}

#pragma mark - lazyload
- (UIScrollView *)scrollView {
    if (!_scrollView) {
        _scrollView = [[UIScrollView alloc] init];
    }
    return _scrollView;
}

- (ZPTextView *)textView {
    if (!_textView) {
        _textView = [ZPTextView new];
        _textView.placeholder = @"What's happening?";
        _textView.placeholderFont = [UIFont systemFontOfSize:17];
        _textView.font            = [UIFont systemFontOfSize:17];
        _textView.isAdaptiveHeight = YES;
        _textView.frame = CGRectMake(0, 0, SCREEN_WIDTH, 50);
    }
    return _textView;
}

- (UIView *)toolbar {
    if (!_toolbar) {
        _toolbar = [UIView new];
        _toolbar.backgroundColor = [UIColor whiteColor];
        _toolbar.size = CGSizeMake(self.view.width, kToolbarHeight);
        _toolbar.autoresizingMask = UIViewAutoresizingFlexibleWidth;
        
        _toolbarBackground = [UIView new];
        _toolbarBackground.backgroundColor = [UIColor whiteColor];
        _toolbarBackground.size = CGSizeMake(_toolbar.width, 46);
        _toolbarBackground.bottom = _toolbar.height;
        _toolbarBackground.autoresizingMask = UIViewAutoresizingFlexibleTopMargin | UIViewAutoresizingFlexibleWidth;
        [_toolbar addSubview:_toolbarBackground];
        
        _toolbarBackground.height = 300; // extend
        
        UIView *line = [UIView new];
        line.backgroundColor =  UIColorFromRGB(0xBFBFBF);
        line.width = _toolbarBackground.width;
        line.height = 1;
        line.autoresizingMask = UIViewAutoresizingFlexibleWidth;
        [_toolbarBackground addSubview:line];
        
        
        _toolbarPictureButton = [self _toolbarButtonWithImage:@"compose_toolbar_picture"
                                                    highlight:@"compose_toolbar_picture"];
        _toolbarVideoButton = [self _toolbarButtonWithImage:@"compose_toolbar_video"
                                                  highlight:@"compose_toolbar_video"];
        
        CGFloat one = _toolbar.width / 5;
        _toolbarPictureButton.centerX = one * 0.5;
        _toolbarVideoButton.centerX = one * 1.5;
        
        _toolbar.bottom = self.view.height;
    }
    return _toolbar;
}

- (UIButton *)playBtn {
    if (!_playBtn) {
        _playBtn = [UIButton buttonWithType:UIButtonTypeCustom];
        [_playBtn setImage:[UIImage imageNamed:@"ic_video_play"] forState:UIControlStateNormal];
        [_playBtn addTarget:self action:@selector(onVideoPlayClicked) forControlEvents:UIControlEventTouchUpInside];
    }
    return _playBtn;
}

- (UIButton *)closeBtn {
    if (!_closeBtn) {
        _closeBtn = [UIButton buttonWithType:UIButtonTypeCustom];
        [_closeBtn setImage:[UIImage imageNamed:@"ic_video_close"] forState:UIControlStateNormal];
        [_closeBtn addTarget:self action:@selector(onVideoCloseClicked) forControlEvents:UIControlEventTouchUpInside];
    }
    return _closeBtn;
}
@end
