//
//  ZPSearchResultViewController.h
//  toudalianyuan
//
//  Created by Biao Geng on 2019/7/26.
//  Copyright © 2019年 Peng Zhou. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface ZPSearchResultViewController : UIViewController
//dynamic data
@property (nonatomic,strong) NSArray *dynamicData;
@end

NS_ASSUME_NONNULL_END
