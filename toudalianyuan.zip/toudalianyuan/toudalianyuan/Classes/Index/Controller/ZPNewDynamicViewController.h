//
//  ZPNewDynamicViewController.h
//  toudalianyuan
//
//  Created by Biao Geng on 2019/7/26.
//  Copyright © 2019年 Peng Zhou. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface ZPNewDynamicViewController : UIViewController
@property (nonatomic,copy) void (^updateDynamicsBlock) (void);
@end

NS_ASSUME_NONNULL_END
