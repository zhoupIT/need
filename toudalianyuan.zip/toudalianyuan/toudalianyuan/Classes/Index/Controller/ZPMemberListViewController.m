//
//  ZPMemberListViewController.m
//  toudalianyuan
//
//  Created by Z P on 2019/8/9.
//  Copyright © 2019年 Peng Zhou. All rights reserved.
//

#import "ZPMemberListViewController.h"
#import "ZPMemberTableViewCell.h"
@interface ZPMemberListViewController ()<UITableViewDataSource,UITableViewDelegate>
@property (nonatomic,strong) UITableView *tableView;
@property (nonatomic,strong) NSMutableArray *memberData;
@end

@implementation ZPMemberListViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self initUI];
    [self getMembers];
}

- (void)initUI {
    self.title = @"Team Member";
    self.view.backgroundColor = RGB(241, 241, 241);
    [self.view addSubview:self.tableView];
    self.tableView.sd_layout.spaceToSuperView(UIEdgeInsetsZero);
}

#pragma mark - tableView delegate
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return self.memberData.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    ZPMemberTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:NSStringFromClass([ZPMemberTableViewCell class])];
    cell.model = self.memberData[indexPath.row];
    return cell;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    return 170;
}

#pragma mark - privite
- (void)getMembers {
    WEAK_SELF(weakSelf);
    [[ZPNetWorkTool sharedZPNetWorkTool] GETRequestWith:@"show" parameters:nil progress:^(NSProgress *progress) {
        
    } success:^(NSURLSessionDataTask *task, id response) {
        weakSelf.memberData = [ZPLoginUserModel mj_objectArrayWithKeyValuesArray:[response objectForKey:@"data"]];
        [weakSelf.tableView reloadData];
    } failed:^(NSURLSessionDataTask *task, NSError *error) {
        
    } className:[ZPMemberListViewController class]];
}

#pragma mark - lazyload
- (UITableView *)tableView {
    if (!_tableView) {
        _tableView = [[UITableView alloc] initWithFrame:CGRectZero style:UITableViewStylePlain];
        _tableView.dataSource = self;
        _tableView.delegate = self;
        _tableView.tableFooterView = [UIView new];
        [_tableView registerClass:[ZPMemberTableViewCell class] forCellReuseIdentifier:NSStringFromClass([ZPMemberTableViewCell class])];
        _tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    }
    return _tableView;
}
@end
