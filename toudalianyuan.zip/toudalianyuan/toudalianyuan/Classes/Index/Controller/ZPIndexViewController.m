//
//  ViewController.m
//  toudalianyuan
//
//  Created by Biao Geng on 2019/7/19.
//  Copyright © 2019年 Peng Zhou. All rights reserved.
//

#import "ZPIndexViewController.h"

#import "ZPDynamicModel.h"

#import "ZPSearchResultViewController.h"
#import "ZPNewDynamicViewController.h"
#import "ZPChatViewController.h"
#import "ZPMemberListViewController.h"

#import "ZPMemberCollectionViewCell.h"
#import "ZPDynamicTableviewCell.h"
#import "ZPMemberHeaderView.h"

#import "ZPMemberCyclePagerLayout.h"

#import "WMPlayer.h"
@interface ZPIndexViewController ()<UICollectionViewDataSource,UICollectionViewDelegate,UITableViewDataSource,UITableViewDelegate,WMPlayerDelegate>
@property (nonatomic,strong) UIView *topView;
@property (nonatomic,strong) UITextField *searchTextField;
@property (nonatomic,strong) UIButton *searchBtn;

//member data
@property (nonatomic,strong) NSMutableArray *memberData;
@property (nonatomic,strong) UICollectionView *collectionView;

//dynamic data
@property (nonatomic,strong) NSMutableArray *dynamicData;
@property (nonatomic,strong) UITableView *tableView;

@property (nonatomic,assign) NSInteger page;

@property(nonatomic,strong)WMPlayer *wmPlayer;
@property(nonatomic,strong)ZPDynamicTableviewCell *currentCell;
@end

@implementation ZPIndexViewController
- (void)viewDidLoad {
    [super viewDidLoad];
    [self initUI];
    [self getMembers];
}

- (void)initUI {
    //UIBarButtonItem right
    self.navigationItem.rightBarButtonItem = [UIBarButtonItem itemWithImage:[UIImage imageNamed:@"ic_index_submit"] highlightedImage:nil target:self action:@selector(onSubmitClicked) forControlEvents:UIControlEventTouchUpInside];
    
    self.view.backgroundColor = RGB(241, 241, 241);
    [self.view sd_addSubviews:@[self.tableView,self.topView]];
    //search view
    self.topView.sd_layout.topEqualToView(self.view)
    .leftEqualToView(self.view)
    .rightEqualToView(self.view)
    .heightIs(50);
    
    [self.topView sd_addSubviews:@[self.searchBtn,self.searchTextField]];
    self.searchBtn.sd_layout
    .rightSpaceToView(self.topView, 10)
    .centerYEqualToView(self.topView)
    .widthIs(80)
    .heightIs(34);
    self.searchBtn.sd_cornerRadius = @17;
    
    self.searchTextField.sd_layout
    .leftSpaceToView(self.topView, 10)
    .centerYEqualToView(self.topView)
    .heightIs(34)
    .rightSpaceToView(self.searchBtn, 20);
    self.searchTextField.sd_cornerRadius = @17;
    //dynamic tableView
    self.tableView.sd_layout
    .topSpaceToView(self.topView, 0)
    .leftEqualToView(self.view)
    .rightEqualToView(self.view)
    .bottomEqualToView(self.view);
    //member collectionview
    WEAK_SELF(weakSelf);
    UIView *head = [[UIView alloc] initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, 200)];
    ZPMemberHeaderView *headerView = [[ZPMemberHeaderView alloc] initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, 30)];
    headerView.onSeeAllBlock = ^{
        ZPMemberListViewController *memberListController = [[ZPMemberListViewController alloc] init];
        [weakSelf.navigationController pushViewController:memberListController animated:YES];
    };
    [head sd_addSubviews:@[headerView,self.collectionView]];
    self.tableView.tableHeaderView = head;
    self.tableView.mj_header = [MJRefreshNormalHeader headerWithRefreshingBlock:^{
        [weakSelf getMembers];
        [weakSelf getDynamics];
    }];
    [self.tableView.mj_header beginRefreshing];
    //footer
    self.tableView.mj_footer = [MJRefreshBackNormalFooter footerWithRefreshingTarget:self refreshingAction:@selector(loadMoreData)];
    
    //获取设备旋转方向的通知,即使关闭了自动旋转,一样可以监测到设备的旋转方向
    [[UIDevice currentDevice] beginGeneratingDeviceOrientationNotifications];
    //旋转屏幕通知
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(onDeviceOrientationChange:)
                                                 name:UIDeviceOrientationDidChangeNotification
                                               object:nil];
}

#pragma mark - tableView delegate
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return self.dynamicData.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    ZPDynamicTableviewCell *cell = [tableView dequeueReusableCellWithIdentifier:NSStringFromClass([ZPDynamicTableviewCell class])];
    cell.dynamicModel = self.dynamicData[indexPath.row];
    WEAK_SELF(weakSelf);
    cell.onShowMoreBlock = ^(ZPDynamicModel * _Nonnull dynamicModel) {
        ZPLog(@"%@",dynamicModel);
        [weakSelf chooseActionWithDynamicModel:dynamicModel];
    };
    cell.onPlayClickedBlock = ^(UIView *previewBg,ZPDynamicModel * _Nonnull dynamicModel) {
        [weakSelf releaseWMPlayer];
        weakSelf.currentCell = (ZPDynamicTableviewCell *)previewBg.superview.superview;
        WMPlayerModel *playerModel = [WMPlayerModel new];
        playerModel.videoURL = [NSURL URLWithString:dynamicModel.video];
        playerModel.indexPath = indexPath;
        weakSelf.wmPlayer = [[WMPlayer alloc] init];
        weakSelf.wmPlayer.delegate = weakSelf;
        weakSelf.wmPlayer.playerModel = playerModel;
        [previewBg addSubview:weakSelf.wmPlayer];
        weakSelf.wmPlayer.sd_layout
        .spaceToSuperView(UIEdgeInsetsZero);
        [weakSelf.wmPlayer play];
    };
    return cell;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    ZPDynamicModel *model = self.dynamicData[indexPath.row];
    return [tableView cellHeightForIndexPath:indexPath model:model keyPath:@"dynamicModel" cellClass:[ZPDynamicTableviewCell class] contentViewWidth:SCREEN_WIDTH];
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
}

#pragma mark - collectionView delegate
-(NSInteger)numberOfSectionsInCollectionView:(UICollectionView *)collectionView{
    return 1;
}
-(NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section{
    return self.memberData.count;
}
-(UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath{
    ZPMemberCollectionViewCell * cell = [collectionView dequeueReusableCellWithReuseIdentifier:NSStringFromClass([ZPMemberCollectionViewCell class]) forIndexPath:indexPath];
    cell.model = self.memberData[indexPath.row];
    return cell;
}

- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath {
        [collectionView deselectItemAtIndexPath:indexPath animated:YES];
        ZPChatViewController *pickController = [[ZPChatViewController alloc] init];
        pickController.model = self.memberData[indexPath.row];
        [self.navigationController pushViewController:pickController animated:YES];
}


#pragma mark - privite
- (void)getMembers {
    WEAK_SELF(weakSelf);
    [[ZPNetWorkTool sharedZPNetWorkTool] GETRequestWith:@"show" parameters:@{@"indexShow":@true} progress:^(NSProgress *progress) {
        
    } success:^(NSURLSessionDataTask *task, id response) {
        weakSelf.memberData = [ZPLoginUserModel mj_objectArrayWithKeyValuesArray:[response objectForKey:@"data"]];
        [weakSelf.collectionView reloadData];
    } failed:^(NSURLSessionDataTask *task, NSError *error) {
        
    } className:[ZPIndexViewController class]];
}

- (void)getDynamics {
    WEAK_SELF(weakSelf);
    [[ZPNetWorkTool sharedZPNetWorkTool] GETRequestWith:@"shareList" parameters:@{@"limit":@10} progress:^(NSProgress *progress) {
        
    } success:^(NSURLSessionDataTask *task, id response) {
        //reset the page
        weakSelf.page = 0;
        weakSelf.dynamicData = [ZPDynamicModel mj_objectArrayWithKeyValuesArray:[response objectForKey:@"data"]];
        [weakSelf.tableView reloadData];
        [weakSelf.tableView.mj_header endRefreshing];
    } failed:^(NSURLSessionDataTask *task, NSError *error) {
        [weakSelf.tableView.mj_header endRefreshing];
    } className:[ZPIndexViewController class]];
}

- (void)loadMoreData {
    self.page ++;
    WEAK_SELF(weakSelf);
    [[ZPNetWorkTool sharedZPNetWorkTool] GETRequestWith:@"shareList" parameters:@{@"limit":@10,@"offset":[NSNumber numberWithInteger:10*self.page]} progress:^(NSProgress *progress) {
        
    } success:^(NSURLSessionDataTask *task, id response) {
        if ([[response objectForKey:@"data"] count]) {
            [weakSelf.dynamicData addObjectsFromArray:[ZPDynamicModel mj_objectArrayWithKeyValuesArray:[response objectForKey:@"data"]]];
            [weakSelf.tableView reloadData];
            [weakSelf.tableView.mj_footer endRefreshing];
        } else {
            [weakSelf.tableView.mj_footer endRefreshingWithNoMoreData];
        }
    } failed:^(NSURLSessionDataTask *task, NSError *error) {
        weakSelf.page --;
        [weakSelf.tableView.mj_footer endRefreshing];
    } className:[ZPIndexViewController class]];
}

- (void)onSubmitClicked {
    WEAK_SELF(weakSelf);
    [self.view endEditing:YES];
    NSString *path = NSSearchPathForDirectoriesInDomains(NSCachesDirectory, NSUserDomainMask, YES)[0];
    NSString *filePath = [path stringByAppendingPathComponent:@"user.data"];
    if ([[NSFileManager defaultManager] fileExistsAtPath:filePath]) {
        ZPNewDynamicViewController *newDynamicController = [[ZPNewDynamicViewController alloc] init];
        newDynamicController.updateDynamicsBlock = ^{
            [weakSelf getDynamics];
        };
        [self.navigationController pushViewController:newDynamicController animated:YES];
    } else {
        [MBProgressHUD showError:@"Please login in first!"];
    }
}

- (void)onSearchClicked {
    [self.view endEditing:YES];
    if (self.searchTextField.text.length) {
        WEAK_SELF(weakSelf);
        [MBProgressHUD showMessage:@"Searching..."];
        [[ZPNetWorkTool sharedZPNetWorkTool] GETRequestWith:@"shareList" parameters:@{@"limit":@10,@"shareMsg":self.searchTextField.text} progress:^(NSProgress *progress) {
            
        } success:^(NSURLSessionDataTask *task, id response) {
            [MBProgressHUD hideHUD];
            NSArray *dynamics = [ZPDynamicModel mj_objectArrayWithKeyValuesArray:[response objectForKey:@"data"]];
            ZPSearchResultViewController *searchResultController = [[ZPSearchResultViewController alloc] init];
            searchResultController.dynamicData = dynamics;
            [weakSelf.navigationController pushViewController:searchResultController animated:YES];
        } failed:^(NSURLSessionDataTask *task, NSError *error) {
            [MBProgressHUD hideHUD];
        } className:[ZPIndexViewController class]];
    }
}


-(void)chooseActionWithDynamicModel:(ZPDynamicModel *)model {
    [self.view endEditing:YES];
    NSString *path = NSSearchPathForDirectoriesInDomains(NSCachesDirectory, NSUserDomainMask, YES)[0];
    NSString *filePath = [path stringByAppendingPathComponent:@"user.data"];
    if ([[NSFileManager defaultManager] fileExistsAtPath:filePath]) {
        UIAlertController *actionSheet = [UIAlertController alertControllerWithTitle:[NSString stringWithFormat:@"Choose Action->'%@'",model.nickname] message:model.shareMsg preferredStyle:UIAlertControllerStyleActionSheet];
        
        UIAlertAction *action_copy = [UIAlertAction actionWithTitle:@"Copy Text" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
            ZPLog(@"Copy Text");
            UIPasteboard *pasteboard = [UIPasteboard generalPasteboard];
            pasteboard.string = model.shareMsg;
            [MBProgressHUD showSuccess:@"Copy Success"];
        }];
        UIAlertAction *action_report = [UIAlertAction actionWithTitle:@"Report content" style:UIAlertActionStyleDestructive handler:^(UIAlertAction * _Nonnull action) {
            ZPLog(@"Report content");
            [[ZPNetWorkTool sharedZPNetWorkTool] POSTRequestWithUrlString:[NSString stringWithFormat:@"/api/share/report/%@",model.userId] parameters:nil progress:^(NSProgress *progress) {
                
            } success:^(NSURLSessionDataTask *task, id response) {
                [MBProgressHUD showSuccess:@"Report Success,we will check it!"];
            } failed:^(NSURLSessionDataTask *task, NSError *error) {
                
            } className:[ZPIndexViewController class]];
        }];
        UIAlertAction *action_cancel = [UIAlertAction actionWithTitle:@"Cancel" style:UIAlertActionStyleCancel handler:nil];
        
        //把action添加到actionSheet里
        [actionSheet addAction:action_copy];
        [actionSheet addAction:action_report];
        [actionSheet addAction:action_cancel];
        
        //相当于之前的[actionSheet show];
        [self presentViewController:actionSheet animated:YES completion:nil];
    } else {
       [MBProgressHUD showError:@"Please login in first!"];
    }
}

#pragma mark - video player
-(void)wmplayer:(WMPlayer *)wmplayer clickedCloseButton:(UIButton *)closeBtn{
    NSLog(@"didClickedCloseButton");
    if (wmplayer.isFullscreen) {
        [self toOrientation:UIInterfaceOrientationPortrait];
    }else{
        [self.wmPlayer pause];
        [self releaseWMPlayer];
//        [self.currentCell.playBtn.superview bringSubviewToFront:self.currentCell.playBtn];
    }
}
-(void)wmplayer:(WMPlayer *)wmplayer clickedFullScreenButton:(UIButton *)fullScreenBtn{
    if (self.wmPlayer.isFullscreen) {//全屏
        [self toOrientation:UIInterfaceOrientationPortrait];
    }else{//非全屏
        [self toOrientation:UIInterfaceOrientationLandscapeRight];
    }
}
-(void)wmplayer:(WMPlayer *)wmplayer singleTaped:(UITapGestureRecognizer *)singleTap{
   
}
-(void)wmplayer:(WMPlayer *)wmplayer doubleTaped:(UITapGestureRecognizer *)doubleTap{
  
}

///播放状态
-(void)wmplayerFailedPlay:(WMPlayer *)wmplayer WMPlayerStatus:(WMPlayerState)state{
    NSLog(@"wmplayerDidFailedPlay");
}
-(void)wmplayerReadyToPlay:(WMPlayer *)wmplayer WMPlayerStatus:(WMPlayerState)state{
    NSLog(@"wmplayerDidReadyToPlay");
}
-(void)wmplayerGotVideoSize:(WMPlayer *)wmplayer videoSize:(CGSize )presentationSize{
    
}
-(void)wmplayerFinishedPlay:(WMPlayer *)wmplayer{
    NSLog(@"wmplayerDidFinishedPlay");
}
//操作栏隐藏或者显示都会调用此方法
-(void)wmplayer:(WMPlayer *)wmplayer isHiddenTopAndBottomView:(BOOL)isHidden{
    [self setNeedsStatusBarAppearanceUpdate];
}
/**
 *  旋转屏幕通知
 */
- (void)onDeviceOrientationChange:(NSNotification *)notification{
    if (self.wmPlayer==nil){
        return;
    }
    if (self.wmPlayer.playerModel.verticalVideo) {
        return;
    }
    if (self.wmPlayer.isLockScreen){
        return;
    }
    UIDeviceOrientation orientation = [UIDevice currentDevice].orientation;
    UIInterfaceOrientation interfaceOrientation = (UIInterfaceOrientation)orientation;
    switch (interfaceOrientation) {
        case UIInterfaceOrientationPortraitUpsideDown:{
            NSLog(@"第3个旋转方向---电池栏在下");
        }
            break;
        case UIInterfaceOrientationPortrait:{
            NSLog(@"第0个旋转方向---电池栏在上");
            [self toOrientation:UIInterfaceOrientationPortrait];
        }
            break;
        case UIInterfaceOrientationLandscapeLeft:{
            NSLog(@"第2个旋转方向---电池栏在左");
            [self toOrientation:UIInterfaceOrientationLandscapeLeft];
        }
            break;
        case UIInterfaceOrientationLandscapeRight:{
            NSLog(@"第1个旋转方向---电池栏在右");
            [self toOrientation:UIInterfaceOrientationLandscapeRight];
        }
            break;
        default:
            break;
    }
}
//点击进入,退出全屏,或者监测到屏幕旋转去调用的方法
-(void)toOrientation:(UIInterfaceOrientation)orientation{
    //获取到当前状态条的方向
    UIInterfaceOrientation currentOrientation = [UIApplication sharedApplication].statusBarOrientation;
    [self.wmPlayer removeFromSuperview];
    //根据要旋转的方向,使用Masonry重新修改限制
    if (orientation ==UIInterfaceOrientationPortrait) {
        [self.currentCell.videoBg addSubview:self.wmPlayer];
        self.wmPlayer.isFullscreen = NO;
        self.wmPlayer.backBtnStyle = BackBtnStyleClose;
        self.wmPlayer.sd_layout
        .spaceToSuperView(UIEdgeInsetsZero);
       
    }else{
        [[UIApplication sharedApplication].keyWindow addSubview:self.wmPlayer];
        self.wmPlayer.isFullscreen = YES;
        self.wmPlayer.backBtnStyle = BackBtnStylePop;
        self.wmPlayer.sd_layout
        .spaceToSuperView(UIEdgeInsetsZero);
    }
    //iOS6.0之后,设置状态条的方法能使用的前提是shouldAutorotate为NO,也就是说这个视图控制器内,旋转要关掉;
    //也就是说在实现这个方法的时候-(BOOL)shouldAutorotate返回值要为NO
    if (self.wmPlayer.playerModel.verticalVideo) {
        [self setNeedsStatusBarAppearanceUpdate];
    }else{
        [[UIApplication sharedApplication] setStatusBarOrientation:orientation animated:NO];
        //更改了状态条的方向,但是设备方向UIInterfaceOrientation还是正方向的,这就要设置给你播放视频的视图的方向设置旋转
        //给你的播放视频的view视图设置旋转
        [UIView animateWithDuration:0.4 animations:^{
            self.wmPlayer.transform = CGAffineTransformIdentity;
            self.wmPlayer.transform = [WMPlayer getCurrentDeviceOrientation];
            [self.wmPlayer layoutIfNeeded];
            [self setNeedsStatusBarAppearanceUpdate];
        }];
    }
}

- (void)scrollViewWillBeginDragging:(UIScrollView *)scrollView {
    [self.view endEditing:YES];
}

-(BOOL)prefersStatusBarHidden{
    if (self.wmPlayer.isFullscreen) {
        return self.wmPlayer.prefersStatusBarHidden;
    }
    return NO;
}

/**
 *  释放WMPlayer
 */
-(void)releaseWMPlayer{
    [self.wmPlayer removeFromSuperview];
    self.wmPlayer = nil;
}

-(void)dealloc{
    ZPLog(@"%@ dealloc",[self class]);
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}

#pragma mark - lazyload
- (UIView *)topView {
    if (!_topView) {
        _topView = [UIView new];
        _topView.backgroundColor = [UIColor whiteColor];
        
    }
    return _topView;
}

- (UITextField *)searchTextField {
    if (!_searchTextField) {
        _searchTextField = [UITextField new];
        _searchTextField.placeholder = @"Search Dynamics";
        _searchTextField.backgroundColor = RGB(245, 245, 245);
        _searchTextField.font = [UIFont fontWithName:ZPPFSCRegular size:12];
        UIView *lView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 35, 40)];
        lView.backgroundColor = RGB(245, 245, 245);
        UIImageView *icon = [UIImageView new];
        icon.image = [UIImage imageNamed:@"ic_index_search"];
        [lView addSubview:icon];
        icon.sd_layout.leftSpaceToView(lView, 10)
        .widthIs(15)
        .heightIs(15)
        .centerYEqualToView(lView);
        _searchTextField.leftView = lView;
        _searchTextField.leftViewMode = UITextFieldViewModeAlways;
    }
    return _searchTextField;
}

- (UIButton *)searchBtn {
    if (!_searchBtn) {
        _searchBtn = [UIButton buttonWithType:UIButtonTypeCustom];
        [_searchBtn setTitle:@"Search" forState:UIControlStateNormal];
        [_searchBtn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
        [_searchBtn setBackgroundColor:UIColorFromRGB(0x6a483f)];
        _searchBtn.titleLabel.font = [UIFont fontWithName:ZPPFSCLight size:12];
        [_searchBtn addTarget:self action:@selector(onSearchClicked) forControlEvents:UIControlEventTouchUpInside];
    }
    return _searchBtn;
}

- (UICollectionView *)collectionView {
    if (!_collectionView) {
        //flowlayout
        ZPMemberCyclePagerLayout* layout = [[ZPMemberCyclePagerLayout alloc]init];
        layout.itemSize = CGSizeMake(SCREEN_WIDTH-80, 150);
        layout.minimumLineSpacing = 10;
        _collectionView = [[UICollectionView alloc] initWithFrame:CGRectMake(0, 30, SCREEN_WIDTH, 170) collectionViewLayout:layout];
        CGFloat margin = SCREEN_WIDTH / 2 - layout.itemSize.width / 2;
        _collectionView.contentInset = UIEdgeInsetsMake(0, margin, 0, margin);
        _collectionView.showsVerticalScrollIndicator = NO;
        _collectionView.showsHorizontalScrollIndicator = NO;
        _collectionView.dataSource = self;
        _collectionView.delegate = self;
        _collectionView.backgroundColor = RGB(241, 241, 241);
        [_collectionView registerClass:[ZPMemberCollectionViewCell class] forCellWithReuseIdentifier:NSStringFromClass([ZPMemberCollectionViewCell class])];
    }
    return _collectionView;
}

- (UITableView *)tableView {
    if (!_tableView) {
        _tableView = [[UITableView alloc] initWithFrame:CGRectZero style:UITableViewStylePlain];
        _tableView.backgroundColor = RGB(241, 241, 241);
        _tableView.delegate = self;
        _tableView.dataSource = self;
        _tableView.tableFooterView = [UIView new];
        _tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
        [_tableView registerClass:[ZPDynamicTableviewCell class] forCellReuseIdentifier:NSStringFromClass([ZPDynamicTableviewCell class])];
    }
    return _tableView;
}

- (NSMutableArray *)memberData {
    if (!_memberData) {
        _memberData = [NSMutableArray arrayWithCapacity:0];
    }
    return _memberData;
}

- (NSMutableArray *)dynamicData {
    if (!_dynamicData) {
        _dynamicData = [NSMutableArray arrayWithCapacity:0];
    }
    return _dynamicData;
}
@end
