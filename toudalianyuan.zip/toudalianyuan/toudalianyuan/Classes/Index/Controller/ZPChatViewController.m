//
//  ZPChatViewController.m
//  toudalianyuan
//
//  Created by Z P on 2019/8/8.
//  Copyright © 2019年 Peng Zhou. All rights reserved.
//

#import "ZPChatViewController.h"

@interface ZPChatViewController ()
@property (nonatomic,strong) UIButton *backBtn;
@property (nonatomic,strong) UIView *cardView;
@property (nonatomic,strong) UIImageView *iconView;
@property (nonatomic,strong) UILabel *nameLabel;
@property (nonatomic,strong) UILabel *levelLabel;
@property (nonatomic,strong) UILabel *descLabel;
@property (nonatomic,strong) UIButton *chatBtn;
@end

@implementation ZPChatViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self initUI];
    [self initData];
}

- (void)initUI {
    self.view.backgroundColor = RGB(43, 50, 91);
    [self.view sd_addSubviews:@[self.cardView,self.backBtn,self.iconView]];
    self.backBtn.sd_layout
    .leftSpaceToView(self.view, 20)
    .topSpaceToView(self.view, 30)
    .widthIs(25)
    .heightIs(25);
    
    self.cardView.sd_layout
    .topSpaceToView(self.view, 100)
    .leftSpaceToView(self.view, 10)
    .rightSpaceToView(self.view, 10);
    
    [self.cardView sd_addSubviews:@[self.nameLabel,self.descLabel,self.levelLabel,self.chatBtn]];
    
    self.iconView.sd_layout
    .topSpaceToView(self.view, 50)
    .heightIs(100)
    .widthIs(100)
    .centerXEqualToView(self.cardView);
    
    self.nameLabel.sd_layout
    .topSpaceToView(self.cardView, 100)
    .leftSpaceToView(self.cardView, 10)
    .rightSpaceToView(self.cardView, 10)
    .autoHeightRatio(0);
    
    self.levelLabel.sd_layout
    .leftSpaceToView(self.cardView, 40)
    .rightSpaceToView(self.cardView, 40)
    .topSpaceToView(self.nameLabel, 10)
    .autoHeightRatio(0);
    
    self.descLabel.sd_layout
    .topSpaceToView(self.levelLabel, 20)
    .leftSpaceToView(self.cardView, 40)
    .rightSpaceToView(self.cardView, 40)
    .autoHeightRatio(0);

    
    self.chatBtn.sd_layout
    .topSpaceToView(self.descLabel, 50)
    .leftSpaceToView(self.cardView, 40)
    .rightSpaceToView(self.cardView, 40)
    .heightIs(44);
    
    [self.cardView setupAutoHeightWithBottomView:self.chatBtn bottomMargin:30];
}

- (void)initData {
    [self.iconView sd_setImageWithURL:[NSURL URLWithString:self.model.portrait]];
    self.nameLabel.text = self.model.nickname;
    self.levelLabel.text = [NSString stringWithFormat:@"Level:%@",self.model.customerLevel];
    self.descLabel.text = [NSString stringWithFormat:@"Desc:\"%@\"",self.model.declaration];
}

- (void)onBackClicked {
    [self.navigationController popViewControllerAnimated:YES];
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    self.navigationController.navigationBar.hidden = YES;
}

- (void)viewWillDisappear:(BOOL)animated {
    [super viewWillDisappear:animated];
    self.navigationController.navigationBar.hidden = NO;
}

#pragma mark - lazyload
- (UIButton *)backBtn {
    if (!_backBtn) {
        _backBtn = [UIButton buttonWithType:UIButtonTypeCustom];
        [_backBtn setImage:[UIImage imageNamed:@"common_back"] forState:UIControlStateNormal];
        [_backBtn setImage:[UIImage imageNamed:@"common_back"] forState:UIControlStateHighlighted];
        [_backBtn addTarget:self action:@selector(onBackClicked) forControlEvents:UIControlEventTouchUpInside];
    }
    return _backBtn;
}

- (UIView *)cardView {
    if (!_cardView) {
        _cardView = [UIView new];
        _cardView.backgroundColor = [UIColor whiteColor];
        _cardView.layer.cornerRadius = 5;
        _cardView.layer.masksToBounds = YES;
    }
    return _cardView;
}

- (UIImageView *)iconView {
    if (!_iconView) {
        _iconView = [UIImageView new];
        _iconView.layer.cornerRadius = 5;
        _iconView.layer.masksToBounds = YES;
    }
    return _iconView;
}

- (UILabel *)nameLabel {
    if (!_nameLabel) {
        _nameLabel = [UILabel new];
        _nameLabel.font = [UIFont fontWithName:ZPPFSCMedium size:18];
        _nameLabel.textAlignment = NSTextAlignmentCenter;
    }
    return _nameLabel;
}

- (UILabel *)levelLabel {
    if (!_levelLabel) {
        _levelLabel = [UILabel new];
        _levelLabel.font = [UIFont fontWithName:ZPPFSCRegular size:13];
        _levelLabel.textColor = RGB(150, 150, 152);
        _levelLabel.textAlignment = NSTextAlignmentCenter;
    }
    return _levelLabel;
}

- (UILabel *)descLabel {
    if (!_descLabel) {
        _descLabel = [UILabel new];
        _descLabel.font = [UIFont fontWithName:ZPPFSCRegular size:15];
        _descLabel.textColor = RGB(150, 150, 152);
    }
    return _descLabel;
}

- (UIButton *)chatBtn {
    if (!_chatBtn) {
        _chatBtn = [UIButton buttonWithType:UIButtonTypeCustom];
        _chatBtn.titleLabel.font = [UIFont fontWithName:ZPPFSCMedium size:16];
        _chatBtn.titleLabel.textAlignment = NSTextAlignmentCenter;
        [_chatBtn setTitle:@"CHAT" forState:UIControlStateNormal];
        [_chatBtn setBackgroundColor:RGB(89, 214, 202)];
        [_chatBtn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    }
    return _chatBtn;
}

@end
