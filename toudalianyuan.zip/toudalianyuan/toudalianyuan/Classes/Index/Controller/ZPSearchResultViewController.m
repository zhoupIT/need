//
//  ZPSearchResultViewController.m
//  toudalianyuan
//
//  Created by Biao Geng on 2019/7/26.
//  Copyright © 2019年 Peng Zhou. All rights reserved.
//

#import "ZPSearchResultViewController.h"
#import "ZPDynamicTableviewCell.h"
#import "ZPDynamicModel.h"
#import "WMPlayer.h"
@interface ZPSearchResultViewController ()<UITableViewDataSource,UITableViewDelegate,WMPlayerDelegate>
@property (nonatomic,strong) UITableView *tableView;
@property(nonatomic,strong)WMPlayer *wmPlayer;
@property(nonatomic,strong)ZPDynamicTableviewCell *currentCell;
@end

@implementation ZPSearchResultViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self initUI];
}

- (void)initUI {
    self.title = @"Search Results";
    self.view.backgroundColor = RGB(241, 241, 241);
    [self.view sd_addSubviews:@[self.tableView]];
    //dynamic tableView
    self.tableView.sd_layout
    .topSpaceToView(self.view, 0)
    .leftEqualToView(self.view)
    .rightEqualToView(self.view)
    .bottomEqualToView(self.view);
    //获取设备旋转方向的通知,即使关闭了自动旋转,一样可以监测到设备的旋转方向
    [[UIDevice currentDevice] beginGeneratingDeviceOrientationNotifications];
    //旋转屏幕通知
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(onDeviceOrientationChange:)
                                                 name:UIDeviceOrientationDidChangeNotification
                                               object:nil];
}

#pragma mark - datasource
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return self.dynamicData.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    ZPDynamicTableviewCell *cell = [tableView dequeueReusableCellWithIdentifier:NSStringFromClass([ZPDynamicTableviewCell class])];
    cell.dynamicModel = self.dynamicData[indexPath.row];
    WEAK_SELF(weakSelf);
    cell.onShowMoreBlock = ^(ZPDynamicModel * _Nonnull dynamicModel) {
        [weakSelf chooseActionWithDynamicModel:dynamicModel];
    };
    cell.onPlayClickedBlock = ^(UIView * _Nonnull previewBg, ZPDynamicModel * _Nonnull dynamicModel) {
        [weakSelf releaseWMPlayer];
        weakSelf.currentCell = (ZPDynamicTableviewCell *)previewBg.superview.superview;
        WMPlayerModel *playerModel = [WMPlayerModel new];
        playerModel.videoURL = [NSURL URLWithString:dynamicModel.video];
        playerModel.indexPath = indexPath;
        weakSelf.wmPlayer = [[WMPlayer alloc] init];
        weakSelf.wmPlayer.delegate = weakSelf;
        weakSelf.wmPlayer.playerModel = playerModel;
        [previewBg addSubview:weakSelf.wmPlayer];
        weakSelf.wmPlayer.sd_layout
        .spaceToSuperView(UIEdgeInsetsZero);
        [weakSelf.wmPlayer play];
    };
    return cell;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    ZPDynamicModel *model = self.dynamicData[indexPath.row];
    return [tableView cellHeightForIndexPath:indexPath model:model keyPath:@"dynamicModel" cellClass:[ZPDynamicTableviewCell class] contentViewWidth:SCREEN_WIDTH];
}

#pragma mark - privite
-(void)chooseActionWithDynamicModel:(ZPDynamicModel *)model {
    if ([kUSER_DEFAULT objectForKey:@"ownID"]) {
        UIAlertController *actionSheet = [UIAlertController alertControllerWithTitle:[NSString stringWithFormat:@"Choose Action->'%@'",model.nickname] message:model.shareMsg preferredStyle:UIAlertControllerStyleActionSheet];
        
        UIAlertAction *action_copy = [UIAlertAction actionWithTitle:@"Copy Text" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
            ZPLog(@"Copy Text");
            UIPasteboard *pasteboard = [UIPasteboard generalPasteboard];
            pasteboard.string = model.shareMsg;
            [MBProgressHUD showSuccess:@"Copy Success"];
        }];
        UIAlertAction *action_report = [UIAlertAction actionWithTitle:@"Report content" style:UIAlertActionStyleDestructive handler:^(UIAlertAction * _Nonnull action) {
            ZPLog(@"Report content");
            [[ZPNetWorkTool sharedZPNetWorkTool] POSTRequestWithUrlString:[NSString stringWithFormat:@"/api/share/report/%@",model.userId] parameters:nil progress:^(NSProgress *progress) {
                
            } success:^(NSURLSessionDataTask *task, id response) {
                [MBProgressHUD showSuccess:@"Report Success,we will check it!"];
            } failed:^(NSURLSessionDataTask *task, NSError *error) {
                
            } className:[ZPSearchResultViewController class]];
        }];
        UIAlertAction *action_cancel = [UIAlertAction actionWithTitle:@"Cancel" style:UIAlertActionStyleCancel handler:nil];
        
        //把action添加到actionSheet里
        [actionSheet addAction:action_copy];
        [actionSheet addAction:action_report];
        [actionSheet addAction:action_cancel];
        
        //相当于之前的[actionSheet show];
        [self presentViewController:actionSheet animated:YES completion:nil];
    } else {
        [MBProgressHUD showError:@"Please login in first!"];
    }
}

#pragma mark - video player
-(void)wmplayer:(WMPlayer *)wmplayer clickedCloseButton:(UIButton *)closeBtn{
    NSLog(@"didClickedCloseButton");
    if (wmplayer.isFullscreen) {
        [self toOrientation:UIInterfaceOrientationPortrait];
    }else{
        [self.wmPlayer pause];
        [self releaseWMPlayer];
        //        [self.currentCell.playBtn.superview bringSubviewToFront:self.currentCell.playBtn];
    }
}
-(void)wmplayer:(WMPlayer *)wmplayer clickedFullScreenButton:(UIButton *)fullScreenBtn{
    if (self.wmPlayer.isFullscreen) {//全屏
        [self toOrientation:UIInterfaceOrientationPortrait];
    }else{//非全屏
        [self toOrientation:UIInterfaceOrientationLandscapeRight];
    }
}
-(void)wmplayer:(WMPlayer *)wmplayer singleTaped:(UITapGestureRecognizer *)singleTap{
    
}
-(void)wmplayer:(WMPlayer *)wmplayer doubleTaped:(UITapGestureRecognizer *)doubleTap{
    
}

///播放状态
-(void)wmplayerFailedPlay:(WMPlayer *)wmplayer WMPlayerStatus:(WMPlayerState)state{
    NSLog(@"wmplayerDidFailedPlay");
}
-(void)wmplayerReadyToPlay:(WMPlayer *)wmplayer WMPlayerStatus:(WMPlayerState)state{
    NSLog(@"wmplayerDidReadyToPlay");
}
-(void)wmplayerGotVideoSize:(WMPlayer *)wmplayer videoSize:(CGSize )presentationSize{
    
}
-(void)wmplayerFinishedPlay:(WMPlayer *)wmplayer{
    NSLog(@"wmplayerDidFinishedPlay");
}
//操作栏隐藏或者显示都会调用此方法
-(void)wmplayer:(WMPlayer *)wmplayer isHiddenTopAndBottomView:(BOOL)isHidden{
    [self setNeedsStatusBarAppearanceUpdate];
}
/**
 *  旋转屏幕通知
 */
- (void)onDeviceOrientationChange:(NSNotification *)notification{
    if (self.wmPlayer==nil){
        return;
    }
    if (self.wmPlayer.playerModel.verticalVideo) {
        return;
    }
    if (self.wmPlayer.isLockScreen){
        return;
    }
    UIDeviceOrientation orientation = [UIDevice currentDevice].orientation;
    UIInterfaceOrientation interfaceOrientation = (UIInterfaceOrientation)orientation;
    switch (interfaceOrientation) {
        case UIInterfaceOrientationPortraitUpsideDown:{
            NSLog(@"第3个旋转方向---电池栏在下");
        }
            break;
        case UIInterfaceOrientationPortrait:{
            NSLog(@"第0个旋转方向---电池栏在上");
            [self toOrientation:UIInterfaceOrientationPortrait];
        }
            break;
        case UIInterfaceOrientationLandscapeLeft:{
            NSLog(@"第2个旋转方向---电池栏在左");
            [self toOrientation:UIInterfaceOrientationLandscapeLeft];
        }
            break;
        case UIInterfaceOrientationLandscapeRight:{
            NSLog(@"第1个旋转方向---电池栏在右");
            [self toOrientation:UIInterfaceOrientationLandscapeRight];
        }
            break;
        default:
            break;
    }
}
//点击进入,退出全屏,或者监测到屏幕旋转去调用的方法
-(void)toOrientation:(UIInterfaceOrientation)orientation{
    //获取到当前状态条的方向
    UIInterfaceOrientation currentOrientation = [UIApplication sharedApplication].statusBarOrientation;
    [self.wmPlayer removeFromSuperview];
    //根据要旋转的方向,使用Masonry重新修改限制
    if (orientation ==UIInterfaceOrientationPortrait) {
        [self.currentCell.videoBg addSubview:self.wmPlayer];
        self.wmPlayer.isFullscreen = NO;
        self.wmPlayer.backBtnStyle = BackBtnStyleClose;
        self.wmPlayer.sd_layout
        .spaceToSuperView(UIEdgeInsetsZero);
        
    }else{
        [[UIApplication sharedApplication].keyWindow addSubview:self.wmPlayer];
        self.wmPlayer.isFullscreen = YES;
        self.wmPlayer.backBtnStyle = BackBtnStylePop;
        self.wmPlayer.sd_layout
        .spaceToSuperView(UIEdgeInsetsZero);
    }
    //iOS6.0之后,设置状态条的方法能使用的前提是shouldAutorotate为NO,也就是说这个视图控制器内,旋转要关掉;
    //也就是说在实现这个方法的时候-(BOOL)shouldAutorotate返回值要为NO
    if (self.wmPlayer.playerModel.verticalVideo) {
        [self setNeedsStatusBarAppearanceUpdate];
    }else{
        [[UIApplication sharedApplication] setStatusBarOrientation:orientation animated:NO];
        //更改了状态条的方向,但是设备方向UIInterfaceOrientation还是正方向的,这就要设置给你播放视频的视图的方向设置旋转
        //给你的播放视频的view视图设置旋转
        [UIView animateWithDuration:0.4 animations:^{
            self.wmPlayer.transform = CGAffineTransformIdentity;
            self.wmPlayer.transform = [WMPlayer getCurrentDeviceOrientation];
            [self.wmPlayer layoutIfNeeded];
            [self setNeedsStatusBarAppearanceUpdate];
        }];
    }
}

-(BOOL)prefersStatusBarHidden{
    if (self.wmPlayer.isFullscreen) {
        return self.wmPlayer.prefersStatusBarHidden;
    }
    return NO;
}

/**
 *  释放WMPlayer
 */
-(void)releaseWMPlayer{
    [self.wmPlayer removeFromSuperview];
    self.wmPlayer = nil;
}

-(void)dealloc{
    ZPLog(@"%@ dealloc",[self class]);
    [self releaseWMPlayer];
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}

#pragma mark - lazyload
- (UITableView *)tableView {
    if (!_tableView) {
        _tableView = [[UITableView alloc] initWithFrame:CGRectZero style:UITableViewStylePlain];
        _tableView.backgroundColor = RGB(241, 241, 241);
        _tableView.dataSource = self;
        _tableView.delegate = self;
        _tableView.tableFooterView = [UIView new];
        _tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
        [_tableView registerClass:[ZPDynamicTableviewCell class] forCellReuseIdentifier:NSStringFromClass([ZPDynamicTableviewCell class])];
    }
    return _tableView;
}

- (NSArray *)dynamicData {
    if (!_dynamicData) {
        _dynamicData = [NSArray array];
    }
    return _dynamicData;
}
@end
