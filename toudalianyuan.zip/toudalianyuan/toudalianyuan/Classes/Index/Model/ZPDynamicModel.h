//
//  ZPDynamicModel.h
//  toudalianyuan
//
//  Created by Biao Geng on 2019/7/25.
//  Copyright © 2019年 Peng Zhou. All rights reserved.
//

#import <Foundation/Foundation.h>
NS_ASSUME_NONNULL_BEGIN

@interface ZPDynamicModel : NSObject
@property (nonatomic,copy) NSString *ID;
@property (nonatomic,copy) NSString *portrait;
@property (nonatomic,copy) NSString *createDate;
@property (nonatomic,copy) NSString *shareMsg;
@property (nonatomic,strong) NSArray *imgList;
@property (nonatomic,copy) NSString *nickname;
@property (nonatomic,copy) NSString *userId;
@property (nonatomic,copy) NSString *video;
@property (nonatomic,assign) BOOL reported;
@end

NS_ASSUME_NONNULL_END
