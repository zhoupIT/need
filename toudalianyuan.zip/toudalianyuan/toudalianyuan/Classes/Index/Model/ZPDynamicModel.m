//
//  ZPDynamicModel.m
//  toudalianyuan
//
//  Created by Biao Geng on 2019/7/25.
//  Copyright © 2019年 Peng Zhou. All rights reserved.
//

#import "ZPDynamicModel.h"

@implementation ZPDynamicModel
+ (NSDictionary *)mj_replacedKeyFromPropertyName {
    return @{@"ID" : @"id"};
}
@end
