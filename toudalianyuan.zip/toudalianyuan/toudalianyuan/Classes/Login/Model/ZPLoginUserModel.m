//
//  ZPLoginUserModel.m
//  toudalianyuan
//
//  Created by Z P on 2019/8/15.
//  Copyright © 2019年 Peng Zhou. All rights reserved.
//

#import "ZPLoginUserModel.h"

@implementation ZPLoginUserModel
MJCodingImplementation
+ (NSDictionary *)mj_replacedKeyFromPropertyName {
    return @{@"ID" : @"id"};
}
@end
