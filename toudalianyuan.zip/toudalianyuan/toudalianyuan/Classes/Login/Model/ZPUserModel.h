//
//  ZPUserModel.h
//  toudalianyuan
//
//  Created by Z P on 2019/8/15.
//  Copyright © 2019年 Peng Zhou. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface ZPUserModel : NSObject
@property (nonatomic,copy) NSString *account;
@property (nonatomic,copy) NSString *invitationCode;
@property (nonatomic,copy) NSString *nickname;
@property (nonatomic,copy) NSString *password;
@property (nonatomic,copy) NSString *performerId;
@property (nonatomic,copy) NSString *portrait;
@end

NS_ASSUME_NONNULL_END
