//
//  ZPLoginUserModel.h
//  toudalianyuan
//
//  Created by Z P on 2019/8/15.
//  Copyright © 2019年 Peng Zhou. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN
@interface ZPLoginUserModel : NSObject
@property (nonatomic,copy) NSString *ID;
@property (nonatomic,copy) NSString *customerLevel;
@property (nonatomic,copy) NSString *declaration;
@property (nonatomic,assign) BOOL indexShow;
@property (nonatomic,copy) NSString *invitationCode;
@property (nonatomic,copy) NSString *nickname;
@property (nonatomic,copy) NSString *portrait;
@property (nonatomic,assign) BOOL teamMember;
@property (nonatomic,copy) NSString *jwt;
@end

NS_ASSUME_NONNULL_END
