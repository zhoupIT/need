//
//  ZPUserModel.m
//  toudalianyuan
//
//  Created by Z P on 2019/8/15.
//  Copyright © 2019年 Peng Zhou. All rights reserved.
//

#import "ZPUserModel.h"

@implementation ZPUserModel

@end
