//
//  ZPSingUpViewController.h
//  toudalianyuan
//
//  Created by Z P on 2019/8/12.
//  Copyright © 2019年 Peng Zhou. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ZPUserModel.h"
NS_ASSUME_NONNULL_BEGIN

@interface ZPSingUpViewController : UIViewController
@property (nonatomic,strong) ZPUserModel *userModel;
@end

NS_ASSUME_NONNULL_END
