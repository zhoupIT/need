//
//  ZPRegisterViewController.m
//  toudalianyuan
//
//  Created by Z P on 2019/8/12.
//  Copyright © 2019年 Peng Zhou. All rights reserved.
//

#import "ZPRegisterViewController.h"
#import "ZPSingUpViewController.h"
#import "ZPUserModel.h"
@interface ZPRegisterViewController ()
@property (nonatomic,strong) UIScrollView *scrollview;
@property (nonatomic,strong) UIButton *backBtn;
@property (nonatomic,strong) UIImageView *bgIcon;
@property (nonatomic,strong) UILabel *nameLabel;
@property (nonatomic,strong) UITextField *nickNameField;
@property (nonatomic,strong) UITextField *pwdField;
@property (nonatomic,strong) UITextField *codeField;
@property (nonatomic,strong) UIButton *signUpBtn;
@end

@implementation ZPRegisterViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self initUI];
}

- (void)initUI {
    self.view.backgroundColor = RGB(246, 246, 246);
    [self.view addSubview:self.scrollview];
    self.scrollview.sd_layout.spaceToSuperView(UIEdgeInsetsZero);
    [self.scrollview sd_addSubviews:@[self.bgIcon,self.backBtn,self.nameLabel,self.nickNameField,self.pwdField,self.codeField,self.signUpBtn]];
    self.bgIcon.sd_layout
    .topSpaceToView(self.scrollview, 50)
    .widthIs(70)
    .heightIs(70)
    .centerXEqualToView(self.scrollview);
    
    self.backBtn.sd_layout
    .leftSpaceToView(self.scrollview, 30)
    .topSpaceToView(self.scrollview, 30)
    .heightIs(30)
    .widthIs(30);
    
    self.nameLabel.sd_layout
    .topSpaceToView(self.bgIcon, 10)
    .leftSpaceToView(self.scrollview, 0)
    .rightSpaceToView(self.scrollview, 0)
    .autoHeightRatio(0);
    
    self.nickNameField.sd_layout
    .topSpaceToView(self.nameLabel, 80)
    .leftSpaceToView(self.scrollview, 30)
    .rightSpaceToView(self.scrollview, 30)
    .heightIs(60);
    
    self.pwdField.sd_layout
    .topSpaceToView(self.nickNameField, 20)
    .leftSpaceToView(self.scrollview, 30)
    .rightSpaceToView(self.scrollview, 30)
    .heightIs(60);
    
    self.codeField.sd_layout
    .topSpaceToView(self.pwdField, 20)
    .leftSpaceToView(self.scrollview, 30)
    .rightSpaceToView(self.scrollview, 30)
    .heightIs(60);
    
    self.signUpBtn.sd_layout
    .topSpaceToView(self.codeField, 40)
    .leftSpaceToView(self.scrollview, 30)
    .rightSpaceToView(self.scrollview, 30)
    .heightIs(60);
    
    self.signUpBtn.layer.shadowColor = UIColorFromRGB(0x999999).CGColor;
    self.signUpBtn.layer.masksToBounds = NO;
    self.signUpBtn.layer.shadowRadius = 3;
    self.signUpBtn.layer.shadowOffset = CGSizeMake(0.0f,4.f);
    self.signUpBtn.layer.shadowOpacity = 0.6f;
    
    self.nickNameField.layer.shadowColor = UIColorFromRGB(0x999999).CGColor;
    self.nickNameField.layer.masksToBounds = NO;
    self.nickNameField.layer.shadowRadius = 3;
    self.nickNameField.layer.shadowOffset = CGSizeMake(0.0f,4.f);
    self.nickNameField.layer.shadowOpacity = 0.6f;
    
    self.pwdField.layer.shadowColor = UIColorFromRGB(0x999999).CGColor;
    self.pwdField.layer.masksToBounds = NO;
    self.pwdField.layer.shadowRadius = 3;
    self.pwdField.layer.shadowOffset = CGSizeMake(0.0f,4.f);
    self.pwdField.layer.shadowOpacity = 0.6f;
    
    self.codeField.layer.shadowColor = UIColorFromRGB(0x999999).CGColor;
    self.codeField.layer.masksToBounds = NO;
    self.codeField.layer.shadowRadius = 3;
    self.codeField.layer.shadowOffset = CGSizeMake(0.0f,4.f);
    self.codeField.layer.shadowOpacity = 0.6f;
    
    [self.scrollview setupAutoContentSizeWithBottomView:self.signUpBtn bottomMargin:20];
}

- (void)onClosePageClicked {
    [self.navigationController popViewControllerAnimated:YES];
}

- (void)onNextClicked {
    [self.view endEditing:YES];
    if (!self.nickNameField.text.length) {
        [MBProgressHUD showError:@"Please input username!"];
        return;
    }
    if (!self.pwdField.text.length) {
        [MBProgressHUD showError:@"Please input password!"];
        return;
    }
    if (!self.codeField.text.length) {
        [MBProgressHUD showError:@"Please input pinterest!"];
        return;
    }
    ZPUserModel *model = [ZPUserModel new];
    model.account = self.nickNameField.text;
    model.password = self.pwdField.text;
    model.invitationCode = self.codeField.text;
    ZPSingUpViewController *signUpController = [[ZPSingUpViewController alloc] init];
    signUpController.userModel = model;
    [self.navigationController pushViewController:signUpController animated:YES];
}


- (UIScrollView *)scrollview {
    if (!_scrollview) {
        _scrollview = [[UIScrollView alloc] init];
    }
    return _scrollview;
}

- (UIButton *)backBtn {
    if (!_backBtn) {
        _backBtn = [UIButton buttonWithType:UIButtonTypeCustom];
        [_backBtn setImage:[UIImage imageNamed:@"ic_signin_back"] forState:UIControlStateNormal];
        [_backBtn addTarget:self action:@selector(onClosePageClicked) forControlEvents:UIControlEventTouchUpInside];
    }
    return _backBtn;
}

- (UIImageView *)bgIcon {
    if (!_bgIcon) {
        _bgIcon = [[UIImageView alloc] init];
        _bgIcon.image = [UIImage imageNamed:@"icon"];
        _bgIcon.layer.cornerRadius = 10;
        _bgIcon.layer.masksToBounds = YES;
    }
    return _bgIcon;
}

- (UILabel *)nameLabel {
    if (!_nameLabel) {
        _nameLabel = [UILabel new];
        _nameLabel.text = @"Creat a new account";
        _nameLabel.font = [UIFont fontWithName:ZPPFSCMedium size:20];
        _nameLabel.textAlignment = NSTextAlignmentCenter;
    }
    return _nameLabel;
}

- (UITextField *)nickNameField {
    if (!_nickNameField) {
        _nickNameField = [[UITextField alloc] init];
        _nickNameField.placeholder = @"Username";
        _nickNameField.layer.cornerRadius = 30;
        _nickNameField.layer.masksToBounds = YES;
        UIView *leftView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 50, 30)];
        UIImageView *left = [[UIImageView alloc] initWithFrame:CGRectZero];
        left.image = [UIImage imageNamed:@"ic_singin_user"];
        [leftView addSubview:left];
        left.sd_layout
        .widthIs(22)
        .heightIs(22)
        .centerXEqualToView(leftView)
        .centerYEqualToView(leftView);
        _nickNameField.leftView = leftView;
        _nickNameField.leftViewMode = UITextFieldViewModeAlways;
        _nickNameField.backgroundColor = [UIColor whiteColor];
    }
    return _nickNameField;
}

- (UITextField *)pwdField {
    if (!_pwdField) {
        _pwdField = [[UITextField alloc] init];
        _pwdField.placeholder = @"Password";
        _pwdField.layer.cornerRadius = 30;
        _pwdField.layer.masksToBounds = YES;
        UIView *leftView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 50, 30)];
        UIImageView *left = [[UIImageView alloc] initWithFrame:CGRectZero];
        left.image = [UIImage imageNamed:@"ic_singin_pwd"];
        [leftView addSubview:left];
        left.sd_layout
        .widthIs(22)
        .heightIs(22)
        .centerXEqualToView(leftView)
        .centerYEqualToView(leftView);
        _pwdField.leftView = leftView;
        _pwdField.leftViewMode = UITextFieldViewModeAlways;
        _pwdField.backgroundColor = [UIColor whiteColor];
    }
    return _pwdField;
}

- (UITextField *)codeField {
    if (!_codeField) {
        _codeField = [[UITextField alloc] init];
        _codeField.placeholder = @"Pinterest";
        _codeField.layer.cornerRadius = 30;
        _codeField.layer.masksToBounds = YES;
        UIView *leftView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 50, 30)];
        UIImageView *left = [[UIImageView alloc] initWithFrame:CGRectZero];
        left.image = [UIImage imageNamed:@"ic_signin_pinterest"];
        [leftView addSubview:left];
        left.sd_layout
        .widthIs(22)
        .heightIs(22)
        .centerXEqualToView(leftView)
        .centerYEqualToView(leftView);
        _codeField.leftView = leftView;
        _codeField.leftViewMode = UITextFieldViewModeAlways;
        _codeField.backgroundColor = [UIColor whiteColor];
    }
    return _codeField;
}

- (UIButton *)signUpBtn {
    if (!_signUpBtn) {
        _signUpBtn = [UIButton buttonWithType:UIButtonTypeCustom];
        [_signUpBtn setTitle:@"NEXT" forState:UIControlStateNormal];
        [_signUpBtn addTarget:self action:@selector(onNextClicked) forControlEvents:UIControlEventTouchUpInside];
        _signUpBtn.backgroundColor = RGB(43, 50, 91);
        _signUpBtn.layer.cornerRadius = 30;
        _signUpBtn.layer.masksToBounds = YES;
        _signUpBtn.titleLabel.font = [UIFont systemFontOfSize:12];
    }
    return _signUpBtn;
}

@end
