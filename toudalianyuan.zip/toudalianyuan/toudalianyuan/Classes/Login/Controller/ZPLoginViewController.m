//
//  ZPLoginViewController.m
//  toudalianyuan
//
//  Created by Biao Geng on 2019/7/26.
//  Copyright © 2019年 Peng Zhou. All rights reserved.
//

#import "ZPLoginViewController.h"
#import "UIButton+Gradient.h"
#import "ZPRegisterViewController.h"
#import "ZPNavigationController.h"
@interface ZPLoginViewController ()
@property (nonatomic,strong) UIScrollView *scrollview;
@property (nonatomic,strong) UIButton *closeBtn;
@property (nonatomic,strong) UIImageView *bgIcon;
@property (nonatomic,strong) UILabel *nameLabel;
@property (nonatomic,strong) UITextField *nickNameField;
@property (nonatomic,strong) UITextField *pwdField;
@property (nonatomic,strong) UIButton *loginBtn;
@property (nonatomic,strong) UILabel *tipLabel;
@property (nonatomic,strong) UIButton *signBtn;
@end

@implementation ZPLoginViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self initUI];
     self.hbd_barHidden = YES;
}

- (void)initUI {
    self.view.backgroundColor = RGB(246, 246, 246);
    [self.view addSubview:self.scrollview];
    self.scrollview.sd_layout.spaceToSuperView(UIEdgeInsetsZero);
    [self.scrollview sd_addSubviews:@[self.bgIcon,self.nameLabel,self.nickNameField,self.pwdField,self.closeBtn,self.loginBtn,self.tipLabel,self.signBtn]];
    self.bgIcon.sd_layout
    .topSpaceToView(self.scrollview, 50)
    .widthIs(70)
    .heightIs(70)
    .centerXEqualToView(self.scrollview);
    
    self.nameLabel.sd_layout
    .topSpaceToView(self.bgIcon, 10)
    .leftSpaceToView(self.scrollview, 0)
    .rightSpaceToView(self.scrollview, 0)
    .autoHeightRatio(0);
    
    
    
    self.closeBtn.sd_layout
    .leftSpaceToView(self.scrollview, 30)
    .topSpaceToView(self.scrollview, 30)
    .heightIs(20)
    .widthIs(20);
    
    self.nickNameField.sd_layout
    .topSpaceToView(self.nameLabel, 80)
    .leftSpaceToView(self.scrollview, 30)
    .rightSpaceToView(self.scrollview, 30)
    .heightIs(60);
    
    self.pwdField.sd_layout
    .topSpaceToView(self.nickNameField, 20)
    .leftSpaceToView(self.scrollview, 30)
    .rightSpaceToView(self.scrollview, 30)
    .heightIs(60);
    
    self.loginBtn.sd_layout
     .topSpaceToView(self.pwdField, 40)
     .leftSpaceToView(self.scrollview, 30)
     .rightSpaceToView(self.scrollview, 30)
    .heightIs(60);
    
    self.tipLabel.sd_layout
    .topSpaceToView(self.loginBtn, 40)
    .leftSpaceToView(self.scrollview, 0)
    .rightSpaceToView(self.scrollview, 0)
    .autoHeightRatio(0);
    
    self.signBtn.sd_layout
    .topSpaceToView(self.tipLabel, 5)
    .widthIs(150)
    .heightIs(14)
    .centerXEqualToView(self.scrollview);
    
    self.loginBtn.layer.shadowColor = UIColorFromRGB(0x999999).CGColor;
    self.loginBtn.layer.masksToBounds = NO;
    self.loginBtn.layer.shadowRadius = 3;
    self.loginBtn.layer.shadowOffset = CGSizeMake(0.0f,4.f);
    self.loginBtn.layer.shadowOpacity = 0.6f;
    
    self.nickNameField.layer.shadowColor = UIColorFromRGB(0x999999).CGColor;
    self.nickNameField.layer.masksToBounds = NO;
    self.nickNameField.layer.shadowRadius = 3;
    self.nickNameField.layer.shadowOffset = CGSizeMake(0.0f,4.f);
    self.nickNameField.layer.shadowOpacity = 0.6f;
    
    self.pwdField.layer.shadowColor = UIColorFromRGB(0x999999).CGColor;
    self.pwdField.layer.masksToBounds = NO;
    self.pwdField.layer.shadowRadius = 3;
    self.pwdField.layer.shadowOffset = CGSizeMake(0.0f,4.f);
    self.pwdField.layer.shadowOpacity = 0.6f;
    
    [self.scrollview setupAutoContentSizeWithBottomView:self.signBtn bottomMargin:20];
}

- (void)onLoginClicked {
    [self.view endEditing:YES];
    if (!self.nickNameField.text.length) {
        [MBProgressHUD showError:@"Please input nickname!"];
        return;
    }
    if (!self.pwdField.text.length) {
        [MBProgressHUD showError:@"Please input password!"];
        return;
    }
    WEAK_SELF(weakSelf);
    [MBProgressHUD showMessage:@"Logining..."];
    [[ZPNetWorkTool sharedZPNetWorkTool] POSTRequestWith:@"login" parameters:@{@"account":self.nickNameField.text,@"password":self.pwdField.text} progress:^(NSProgress *progress) {
        
    } success:^(NSURLSessionDataTask *task, id response) {
        [MBProgressHUD hideHUD];
        [MBProgressHUD showSuccess:@"Login Success!"];
        ZPLoginUserModel *model = [ZPLoginUserModel mj_objectWithKeyValues:[response objectForKey:@"data"]];
        [kUSER_DEFAULT setValue:model.jwt forKey:@"jwt"];
        [kUSER_DEFAULT setValue:model.ID forKey:@"ownID"];
        [kUSER_DEFAULT synchronize];
        NSString *path = NSSearchPathForDirectoriesInDomains(NSCachesDirectory, NSUserDomainMask, YES)[0];
        NSString *filePath = [path stringByAppendingPathComponent:@"user.data"];
        NSLog(@"path:%@",filePath);
        [NSKeyedArchiver archiveRootObject:model toFile:filePath];
        [weakSelf dismissViewControllerAnimated:YES completion:nil];
    } failed:^(NSURLSessionDataTask *task, NSError *error) {
        [MBProgressHUD hideHUD];
    } className:[ZPLoginViewController class]];
}

- (void)onClosePageClicked {
    [self dismissViewControllerAnimated:YES completion:^{
    }];
}

- (void)onSignUpClicked {
    ZPRegisterViewController *registController = [[ZPRegisterViewController alloc] init];
    [self.navigationController pushViewController:registController animated:YES];
}


- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    [UIApplication sharedApplication].statusBarStyle = UIStatusBarStyleDefault;
//    self.navigationController.navigationBar.hidden = YES;
}

- (UIScrollView *)scrollview {
    if (!_scrollview) {
        _scrollview = [[UIScrollView alloc] init];
    }
    return _scrollview;
}

- (UIButton *)closeBtn {
    if (!_closeBtn) {
        _closeBtn = [UIButton buttonWithType:UIButtonTypeCustom];
        [_closeBtn setImage:[UIImage imageNamed:@"ic_close_black"] forState:UIControlStateNormal];
        [_closeBtn addTarget:self action:@selector(onClosePageClicked) forControlEvents:UIControlEventTouchUpInside];
    }
    return _closeBtn;
}

- (UIImageView *)bgIcon {
    if (!_bgIcon) {
        _bgIcon = [[UIImageView alloc] init];
        _bgIcon.image = [UIImage imageNamed:@"icon"];
        _bgIcon.layer.cornerRadius = 10;
        _bgIcon.layer.masksToBounds = YES;
    }
    return _bgIcon;
}

- (UILabel *)nameLabel {
    if (!_nameLabel) {
        _nameLabel = [UILabel new];
        _nameLabel.text = @"Royal Team";
        _nameLabel.font = [UIFont fontWithName:ZPPFSCMedium size:20];
        _nameLabel.textAlignment = NSTextAlignmentCenter;
    }
    return _nameLabel;
}

- (UITextField *)nickNameField {
    if (!_nickNameField) {
        _nickNameField = [[UITextField alloc] init];
        _nickNameField.placeholder = @"Username";
        _nickNameField.layer.cornerRadius = 30;
        _nickNameField.layer.masksToBounds = YES;
        UIView *leftView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 50, 30)];
        UIImageView *left = [[UIImageView alloc] initWithFrame:CGRectZero];
        left.image = [UIImage imageNamed:@"ic_singin_user"];
        [leftView addSubview:left];
        left.sd_layout
        .widthIs(22)
        .heightIs(22)
        .centerXEqualToView(leftView)
        .centerYEqualToView(leftView);
        _nickNameField.leftView = leftView;
        _nickNameField.leftViewMode = UITextFieldViewModeAlways;
        _nickNameField.backgroundColor = [UIColor whiteColor];
    }
    return _nickNameField;
}

- (UITextField *)pwdField {
    if (!_pwdField) {
        _pwdField = [[UITextField alloc] init];
        _pwdField.placeholder = @"Password";
        _pwdField.layer.cornerRadius = 30;
        _pwdField.layer.masksToBounds = YES;
        _pwdField.secureTextEntry = YES;
        UIView *leftView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 50, 30)];
        UIImageView *left = [[UIImageView alloc] initWithFrame:CGRectZero];
        left.image = [UIImage imageNamed:@"ic_singin_pwd"];
        [leftView addSubview:left];
        left.sd_layout
        .widthIs(22)
        .heightIs(22)
        .centerXEqualToView(leftView)
        .centerYEqualToView(leftView);
        _pwdField.leftView = leftView;
        _pwdField.leftViewMode = UITextFieldViewModeAlways;
        _pwdField.backgroundColor = [UIColor whiteColor];
    }
    return _pwdField;
}

- (UIButton *)loginBtn {
    if (!_loginBtn) {
        _loginBtn = [UIButton buttonWithType:UIButtonTypeCustom];
        [_loginBtn setTitle:@"SIGN IN" forState:UIControlStateNormal];
        [_loginBtn addTarget:self action:@selector(onLoginClicked) forControlEvents:UIControlEventTouchUpInside];
        _loginBtn.backgroundColor = RGB(43, 50, 91);
        _loginBtn.layer.cornerRadius = 30;
        _loginBtn.layer.masksToBounds = YES;
        _loginBtn.titleLabel.font = [UIFont systemFontOfSize:12];
    }
    return _loginBtn;
}

- (UILabel *)tipLabel {
    if (!_tipLabel) {
        _tipLabel = [[UILabel alloc] init];
        _tipLabel.text = @"Don't have an account?";
        _tipLabel.textColor = [UIColor lightGrayColor];
        _tipLabel.font = [UIFont fontWithName:ZPPFSCRegular size:10];
        _tipLabel.textAlignment = NSTextAlignmentCenter;
    }
    return _tipLabel;
}

- (UIButton *)signBtn {
    if (!_signBtn) {
        _signBtn = [UIButton buttonWithType:UIButtonTypeCustom];
        [_signBtn setTitle:@"SIGN UP NOW" forState:UIControlStateNormal];
        _signBtn.titleLabel.font = [UIFont fontWithName:ZPPFSCMedium size:13];
        [_signBtn setTitleColor: RGB(92, 149, 179) forState:UIControlStateNormal];
        [_signBtn addTarget:self action:@selector(onSignUpClicked) forControlEvents:UIControlEventTouchUpInside];
    }
    return _signBtn;
}


@end
