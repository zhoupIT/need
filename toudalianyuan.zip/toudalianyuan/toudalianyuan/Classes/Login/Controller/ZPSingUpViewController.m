//
//  ZPSingUpViewController.m
//  toudalianyuan
//
//  Created by Z P on 2019/8/12.
//  Copyright © 2019年 Peng Zhou. All rights reserved.
//

#import "ZPSingUpViewController.h"
#import "TZImagePickerController.h"
#import "ZPLoginUserModel.h"
@interface ZPSingUpViewController ()<TZImagePickerControllerDelegate>
@property (nonatomic,strong) UIScrollView *scrollview;
@property (nonatomic,strong) UIButton *iconView;
@property (nonatomic,strong) UIButton *backBtn;
@property (nonatomic,strong) UIImageView *bgIcon;
@property (nonatomic,strong) UILabel *nameLabel;
@property (nonatomic,strong) UITextField *nickNameField;
@property (nonatomic,strong) UIButton *signUpBtn;
@end

@implementation ZPSingUpViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self initUI];
}

- (void)initUI {
    self.view.backgroundColor = RGB(246, 246, 246);
    [self.view addSubview:self.scrollview];
    self.scrollview.sd_layout.spaceToSuperView(UIEdgeInsetsZero);
    [self.scrollview sd_addSubviews:@[self.bgIcon,self.backBtn,self.nameLabel,self.nickNameField,self.signUpBtn,self.iconView]];
    self.bgIcon.sd_layout
    .topSpaceToView(self.scrollview, 50)
    .widthIs(70)
    .heightIs(70)
    .centerXEqualToView(self.scrollview);
    
    self.backBtn.sd_layout
    .leftSpaceToView(self.scrollview, 30)
    .topSpaceToView(self.scrollview, 30)
    .heightIs(30)
    .widthIs(30);
    
    self.nameLabel.sd_layout
    .topSpaceToView(self.bgIcon, 10)
    .leftSpaceToView(self.scrollview, 0)
    .rightSpaceToView(self.scrollview, 0)
    .autoHeightRatio(0);
    
    self.iconView.sd_layout
    .topSpaceToView(self.nameLabel, 50)
    .widthIs(50)
    .heightIs(50)
    .centerXEqualToView(self.scrollview);
    self.iconView.sd_cornerRadius = @25;
    
    self.nickNameField.sd_layout
    .topSpaceToView(self.iconView, 10)
    .leftSpaceToView(self.scrollview, 30)
    .rightSpaceToView(self.scrollview, 30)
    .heightIs(60);

    
    self.signUpBtn.sd_layout
    .topSpaceToView(self.nickNameField, 40)
    .leftSpaceToView(self.scrollview, 30)
    .rightSpaceToView(self.scrollview, 30)
    .heightIs(60);
    
    self.signUpBtn.layer.shadowColor = UIColorFromRGB(0x999999).CGColor;
    self.signUpBtn.layer.masksToBounds = NO;
    self.signUpBtn.layer.shadowRadius = 3;
    self.signUpBtn.layer.shadowOffset = CGSizeMake(0.0f,4.f);
    self.signUpBtn.layer.shadowOpacity = 0.6f;
    
    self.nickNameField.layer.shadowColor = UIColorFromRGB(0x999999).CGColor;
    self.nickNameField.layer.masksToBounds = NO;
    self.nickNameField.layer.shadowRadius = 3;
    self.nickNameField.layer.shadowOffset = CGSizeMake(0.0f,4.f);
    self.nickNameField.layer.shadowOpacity = 0.6f;
    
    [self.scrollview setupAutoContentSizeWithBottomView:self.signUpBtn bottomMargin:20];
}
#pragma mark - private
- (void)onClosePageClicked {
    [self.navigationController popViewControllerAnimated:YES];
}


- (void)onUploadImgClicked {
    WEAK_SELF(weakSelf);
    TZImagePickerController *imagePickerVc = [[TZImagePickerController alloc] initWithMaxImagesCount:1 delegate:self];
    imagePickerVc.allowPickingGif = NO;
    imagePickerVc.allowTakeVideo = NO;
    imagePickerVc.allowPickingImage = YES;
    imagePickerVc.allowPickingVideo = NO;
    [imagePickerVc setDidFinishPickingPhotosHandle:^(NSArray<UIImage *> *photos, NSArray *assets, BOOL isSelectOriginalPhoto) {
        if (photos.count) {
            [weakSelf.iconView setImage:photos.firstObject forState:UIControlStateNormal];
            [weakSelf uploadImg:assets.firstObject withImg:photos.firstObject];
        }
    }];
    [self presentViewController:imagePickerVc animated:YES completion:nil];
}

- (void)uploadImg:(PHAsset *)asset withImg:(UIImage *)image{
    NSData *data = UIImageJPEGRepresentation(image,0.0);
    WEAK_SELF(weakSelf);
    [[ZPNetWorkTool sharedZPNetWorkTool] POSTRequestWith:@"upload" parameters:nil constructingBodyWithBlock:^(id<AFMultipartFormData> formData) {
        NSString *filename = [asset valueForKey:@"filename"];
        [formData appendPartWithFileData:data name:@"file" fileName:filename mimeType:@"png"];
    } progress:^(NSProgress *progress) {
        
    } success:^(NSURLSessionDataTask *task, id response) {
        [MBProgressHUD showSuccess:@"Upload Image Success"];
        weakSelf.userModel.portrait = [response objectForKey:@"data"];
    } failed:^(NSURLSessionDataTask *task, NSError *error) {

    } className:[ZPSingUpViewController class]];
}


- (void)onSignUpClicked {
    [self.view endEditing:YES];
    if (!self.nickNameField.text.length) {
        [MBProgressHUD showError:@"Please input nickname!"];
        return;
    }
    self.userModel.nickname = self.nickNameField.text;
    if (!self.userModel.portrait.length) {
        [MBProgressHUD showError:@"Please upload portrait!"];
        return;
    }
    WEAK_SELF(weakSelf);
    [MBProgressHUD showMessage:@"Registing..."];
    [[ZPNetWorkTool sharedZPNetWorkTool] POSTRequestWith:@"register" parameters:@{@"account":self.userModel.account,@"password":self.userModel.password,@"portrait":self.userModel.portrait,@"invitationCode":self.userModel.invitationCode,@"nickname":self.userModel.nickname} progress:^(NSProgress *progress) {

    } success:^(NSURLSessionDataTask *task, id response) {
        [MBProgressHUD hideHUD];
        [MBProgressHUD showMessage:@"Logining..."];
        [[ZPNetWorkTool sharedZPNetWorkTool] POSTRequestWith:@"login" parameters:@{@"account":self.userModel.account,@"password":self.userModel.password} progress:^(NSProgress *progress) {

        } success:^(NSURLSessionDataTask *task, id response) {
            [MBProgressHUD hideHUD];
            [MBProgressHUD showSuccess:@"Login Success!"];
            ZPLoginUserModel *model = [ZPLoginUserModel mj_objectWithKeyValues:[response objectForKey:@"data"]];
            [kUSER_DEFAULT setValue:model.jwt forKey:@"jwt"];
            [kUSER_DEFAULT setValue:model.ID forKey:@"ownID"];
            [kUSER_DEFAULT synchronize];
            NSString *path = NSSearchPathForDirectoriesInDomains(NSCachesDirectory, NSUserDomainMask, YES)[0];
            NSString *filePath = [path stringByAppendingPathComponent:@"user.data"];
            NSLog(@"path:%@",filePath);
            [NSKeyedArchiver archiveRootObject:model toFile:filePath];
            [weakSelf dismissViewControllerAnimated:YES completion:nil];
        } failed:^(NSURLSessionDataTask *task, NSError *error) {
            [MBProgressHUD hideHUD];
        } className:[ZPSingUpViewController class]];
    } failed:^(NSURLSessionDataTask *task, NSError *error) {
        [MBProgressHUD hideHUD];
    } className:[ZPSingUpViewController class]];
}
#pragma mark - lazyload
- (UIScrollView *)scrollview {
    if (!_scrollview) {
        _scrollview = [[UIScrollView alloc] init];
    }
    return _scrollview;
}

- (UIButton *)iconView {
    if (!_iconView) {
        _iconView = [UIButton buttonWithType:UIButtonTypeCustom];
        [_iconView setImage:[UIImage imageNamed:@"ic_signin_upload"] forState:UIControlStateNormal];
        [_iconView addTarget:self action:@selector(onUploadImgClicked) forControlEvents:UIControlEventTouchUpInside];
    }
    return _iconView;
}

- (UIButton *)backBtn {
    if (!_backBtn) {
        _backBtn = [UIButton buttonWithType:UIButtonTypeCustom];
        [_backBtn setImage:[UIImage imageNamed:@"ic_signin_back"] forState:UIControlStateNormal];
        [_backBtn addTarget:self action:@selector(onClosePageClicked) forControlEvents:UIControlEventTouchUpInside];
    }
    return _backBtn;
}


- (UIImageView *)bgIcon {
    if (!_bgIcon) {
        _bgIcon = [[UIImageView alloc] init];
        _bgIcon.image = [UIImage imageNamed:@"icon"];
        _bgIcon.layer.cornerRadius = 10;
        _bgIcon.layer.masksToBounds = YES;
    }
    return _bgIcon;
}

- (UILabel *)nameLabel {
    if (!_nameLabel) {
        _nameLabel = [UILabel new];
        _nameLabel.text = @"Personal info";
        _nameLabel.font = [UIFont fontWithName:ZPPFSCMedium size:20];
        _nameLabel.textAlignment = NSTextAlignmentCenter;
    }
    return _nameLabel;
}

- (UITextField *)nickNameField {
    if (!_nickNameField) {
        _nickNameField = [[UITextField alloc] init];
        _nickNameField.placeholder = @"Nickname";
        _nickNameField.layer.cornerRadius = 30;
        _nickNameField.layer.masksToBounds = YES;
        UIView *leftView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 50, 30)];
        UIImageView *left = [[UIImageView alloc] initWithFrame:CGRectZero];
        left.image = [UIImage imageNamed:@"ic_singin_user"];
        [leftView addSubview:left];
        left.sd_layout
        .widthIs(22)
        .heightIs(22)
        .centerXEqualToView(leftView)
        .centerYEqualToView(leftView);
        _nickNameField.leftView = leftView;
        _nickNameField.leftViewMode = UITextFieldViewModeAlways;
        _nickNameField.backgroundColor = [UIColor whiteColor];
    }
    return _nickNameField;
}

- (UIButton *)signUpBtn {
    if (!_signUpBtn) {
        _signUpBtn = [UIButton buttonWithType:UIButtonTypeCustom];
        [_signUpBtn setTitle:@"SIGNUP NOW" forState:UIControlStateNormal];
        [_signUpBtn addTarget:self action:@selector(onSignUpClicked) forControlEvents:UIControlEventTouchUpInside];
        _signUpBtn.backgroundColor = RGB(43, 50, 91);
        _signUpBtn.layer.cornerRadius = 30;
        _signUpBtn.layer.masksToBounds = YES;
        _signUpBtn.titleLabel.font = [UIFont systemFontOfSize:12];
    }
    return _signUpBtn;
}
@end
