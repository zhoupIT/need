//
//  ZPMeTableViewCell.h
//  toudalianyuan
//
//  Created by Biao Geng on 2019/7/25.
//  Copyright © 2019年 Peng Zhou. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface ZPMeTableViewCell : UITableViewCell
@property (nonatomic,strong) NSDictionary *dict;
@end

NS_ASSUME_NONNULL_END
