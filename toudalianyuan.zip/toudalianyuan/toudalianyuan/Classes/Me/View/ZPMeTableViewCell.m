//
//  ZPMeTableViewCell.m
//  toudalianyuan
//
//  Created by Biao Geng on 2019/7/25.
//  Copyright © 2019年 Peng Zhou. All rights reserved.
//

#import "ZPMeTableViewCell.h"

@interface ZPMeTableViewCell()
{
//    UIView      *_containerView;
    UIImageView *_leftIcon;
    UILabel     *_actionLabel;
    UIImageView *_arrowIcon;
}
@end

@implementation ZPMeTableViewCell

- (void)setFrame:(CGRect)frame{
    frame.origin.x += 10;
    frame.origin.y += 10;
    frame.size.height -= 10;
    frame.size.width -= 20;
    [super setFrame:frame];
}

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier {
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        [self initUI];
    }
    return self;
}

- (void)initUI {
//    self.contentView.layer.borderColor = UIColorFromRGB(0xededed).CGColor;
//    self.contentView.layer.borderWidth = 1;
//    self.contentView.layer.cornerRadius = 10;
//    self.contentView.layer.masksToBounds = YES;
    
    _leftIcon = [[UIImageView alloc] init];
    _actionLabel = [[UILabel alloc] init];
    _arrowIcon = [[UIImageView alloc] init];
    [self.contentView sd_addSubviews:@[_leftIcon,_actionLabel,_arrowIcon]];
    _leftIcon.sd_layout
    .centerYEqualToView(self.contentView)
    .leftSpaceToView(self.contentView, 20)
    .widthIs(20)
    .heightIs(20);
    
    _arrowIcon.sd_layout
    .rightSpaceToView(self.contentView, 20)
    .widthIs(8)
    .heightIs(12)
    .centerYEqualToView(self.contentView);
    _arrowIcon.image = [UIImage imageNamed:@"arrow-right"];
    
    _actionLabel.sd_layout
    .leftSpaceToView(_leftIcon, 10)
    .centerYEqualToView(self.contentView)
    .rightSpaceToView(_arrowIcon, 10)
    .autoHeightRatio(0);
    [_actionLabel setMaxNumberOfLinesToShow:1];
    _actionLabel.textColor = UIColorFromRGB(0x808A91);
    _actionLabel.font = [UIFont fontWithName:ZPPFSCRegular size:14];
}

- (void)setDict:(NSDictionary *)dict {
    _dict = dict;
    _leftIcon.image = [UIImage imageNamed:dict[@"icon"]];
    _actionLabel.text = dict[@"title"];
}
@end
