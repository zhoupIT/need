//
//  ZPApplyViewController.m
//  toudalianyuan
//
//  Created by Z P on 2019/8/15.
//  Copyright © 2019年 Peng Zhou. All rights reserved.
//

#import "ZPApplyViewController.h"

@interface ZPApplyViewController ()<UIPickerViewDelegate,UIPickerViewDataSource>
@property (nonatomic,strong) UITextField *levelField;
@property (nonatomic,strong) UITextField *declarField;
@property (nonatomic,strong) UIButton *applyBtn;
@property (nonatomic,strong) NSArray *data;
@property(nonatomic,strong)UIPickerView *pickerView;
@end

@implementation ZPApplyViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self initUI];
}

- (void)initUI {
    self.title = @"Apply";
    self.view.backgroundColor = RGB(241, 241, 241);
    [self.view sd_addSubviews:@[self.levelField,self.declarField,self.applyBtn]];
    self.levelField.sd_layout
    .topSpaceToView(self.view, 20)
    .leftSpaceToView(self.view, 20)
    .rightSpaceToView(self.view, 20)
    .heightIs(50);
    
    self.declarField.sd_layout
    .topSpaceToView(self.levelField, 10)
    .leftSpaceToView(self.view, 20)
    .rightSpaceToView(self.view, 20)
    .heightIs(50);
    
    self.applyBtn.sd_layout
    .topSpaceToView(self.declarField, 20)
    .leftSpaceToView(self.view, 20)
    .rightSpaceToView(self.view, 20)
    .heightIs(50);
}

- (void)onApplyClicked {
    [self.view endEditing:YES];
    if (self.levelField.text.length && self.declarField.text.length) {
        [MBProgressHUD showMessage:@"Loading..."];
        NSString *path = NSSearchPathForDirectoriesInDomains(NSCachesDirectory, NSUserDomainMask, YES)[0];
        NSString *filePath = [path stringByAppendingPathComponent:@"user.data"];
        ZPLoginUserModel *model = [NSKeyedUnarchiver unarchiveObjectWithFile:filePath];
        [[ZPNetWorkTool sharedZPNetWorkTool] POSTRequestWith:@"customer" parameters:@{@"teamMember":@true,@"customerLevel":self.levelField.text,@"declaration":self.declarField.text} progress:^(NSProgress *progress) {
            
        } success:^(NSURLSessionDataTask *task, id response) {
            [MBProgressHUD hideHUD];
            [MBProgressHUD showSuccess:@"Apply Success!"];
            model.teamMember = true;
            model.declaration =self.declarField.text;
            model.customerLevel = self.levelField.text;
            [NSKeyedArchiver archiveRootObject:model toFile:filePath];
            [self.navigationController popViewControllerAnimated:YES];
        } failed:^(NSURLSessionDataTask *task, NSError *error) {
            [MBProgressHUD hideHUD];
        } className:[ZPApplyViewController class]];
    } else {
        [MBProgressHUD showError:@"Please input first!"];
    }
}

#pragma PickerView Delegate
-(NSInteger)numberOfComponentsInPickerView:(UIPickerView *)pickerView{
    return 1;
}

- (NSInteger)pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component{
    return self.data.count;
}

- (NSString *)pickerView:(UIPickerView *)pickerView titleForRow:(NSInteger)row forComponent:(NSInteger)component{
    return [self.data objectAtIndex:row];
}

- (void)pickerView:(UIPickerView *)pickerView didSelectRow:(NSInteger)row inComponent:(NSInteger)component{
    self.levelField.text = [self.data objectAtIndex:row];
}

#pragma mark - lazyload
- (NSArray *)data {
    if (!_data) {
        _data = @[@"Bronze",@"Silver",@"Gold",@"Platinum",@"Diamond",@"Starlight",@"King",@"King of Glory"];
    }
    return _data;
}

- (UITextField *)levelField {
    if (!_levelField) {
        _levelField = [[UITextField alloc] init];
        _levelField.placeholder = @"Select Level";
        _levelField.layer.cornerRadius = 25;
        _levelField.layer.masksToBounds = YES;
        _levelField.backgroundColor = [UIColor whiteColor];
        _levelField.inputView = self.pickerView;
        UIView *leftView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 25, 25)];
        _levelField.leftView = leftView;
        _levelField.leftViewMode = UITextFieldViewModeAlways;
    }
    return _levelField;
}

- (UIPickerView *)pickerView {
    if (!_pickerView) {
        _pickerView = [UIPickerView new];
        _pickerView.delegate = self;
        _pickerView.dataSource = self;
        _pickerView.backgroundColor = [UIColor whiteColor];
    }
    return _pickerView;
}

- (UITextField *)declarField {
    if (!_declarField) {
        _declarField = [[UITextField alloc] init];
        _declarField.placeholder = @"Your Declartion";
        _declarField.layer.cornerRadius = 25;
        _declarField.layer.masksToBounds = YES;
        _declarField.backgroundColor = [UIColor whiteColor];
        UIView *leftView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 25, 25)];
        _declarField.leftView = leftView;
        _declarField.leftViewMode = UITextFieldViewModeAlways;
    }
    return _declarField;
}

- (UIButton *)applyBtn {
    if (!_applyBtn) {
        _applyBtn = [UIButton buttonWithType:UIButtonTypeCustom];
        [_applyBtn setTitle:@"APPLY FOR TEAM MEMBER" forState:UIControlStateNormal];
        [_applyBtn addTarget:self action:@selector(onApplyClicked) forControlEvents:UIControlEventTouchUpInside];
        _applyBtn.backgroundColor = RGB(43, 50, 91);
        _applyBtn.layer.cornerRadius = 25;
        _applyBtn.layer.masksToBounds = YES;
        _applyBtn.titleLabel.font = [UIFont systemFontOfSize:12];
    }
    return _applyBtn;
}

@end
