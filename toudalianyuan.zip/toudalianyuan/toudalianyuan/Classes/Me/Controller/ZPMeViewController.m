//
//  ZPMeViewController.m
//  toudalianyuan
//
//  Created by Biao Geng on 2019/7/25.
//  Copyright © 2019年 Peng Zhou. All rights reserved.
//

#import "ZPMeViewController.h"
#import "ZPMeTableViewCell.h"
#import "ZPHelpViewController.h"
#import "ZPAboutViewController.h"
#import "ZPLoginViewController.h"
#import "ZPMyDynamicsViewController.h"
#import "ZPNavigationController.h"
#import "ZPApplyViewController.h"

@interface ZPMeViewController ()<UITableViewDataSource,UITableViewDelegate>
@property(nonatomic, strong)UITableView     *tableView;
@property(nonatomic, strong)UIImageView     *headerBackView;
@property(nonatomic, strong)UIButton     *photoImageView;
@property(nonatomic, strong)UILabel         *userNameLabel;
@property(nonatomic, strong)UIView          *tableViewHeaderView;
@property(nonatomic, assign)NSInteger       imageHeight;
@property (nonatomic,strong)NSArray         *data;
@end

@implementation ZPMeViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self initUI];
}

#pragma mark - privite
- (void)initUI {
    self.view.backgroundColor = RGB(241, 241, 241);
    _imageHeight = 225;
    [self.view addSubview:self.tableView];
    [self createTableViewHeaderView];
    [self isLogin];
    self.hbd_barHidden = YES;
}

- (void)createTableViewHeaderView
{
    _tableViewHeaderView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, _imageHeight)];
    

    _headerBackView = [[UIImageView alloc] init];
    _headerBackView.frame = CGRectMake(0, 0, SCREEN_WIDTH, _imageHeight);
    _headerBackView.image = [UIImage imageNamed:@"ic_me_headBg"];
    [_tableViewHeaderView addSubview:_headerBackView];
    

    _photoImageView = [[UIButton alloc] initWithFrame:CGRectMake((SCREEN_WIDTH - 70) / 2, 50, 70, 70)];
    [self.tableViewHeaderView addSubview:self.photoImageView];
    _photoImageView.layer.cornerRadius = 35;
    _photoImageView.layer.masksToBounds = YES;
    [_photoImageView sd_setImageWithURL:[NSURL URLWithString:@""] forState:UIControlStateNormal placeholderImage:[UIImage imageNamed:@"ic_ava"]];
    
    [_photoImageView addTarget:self action:@selector(onLoginClicked) forControlEvents:UIControlEventTouchUpInside];
    
  
    _userNameLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, CGRectGetMaxY(_photoImageView.frame) + 10, SCREEN_WIDTH, 20)];
    _userNameLabel.font = [UIFont systemFontOfSize:16];
    _userNameLabel.text = @"SIGN IN";
    _userNameLabel.textAlignment = 1;
    _userNameLabel.textColor = [UIColor whiteColor];
    _userNameLabel.userInteractionEnabled = YES;
    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(onLoginClicked)];
    [_userNameLabel addGestureRecognizer:tap];
    [_tableViewHeaderView addSubview:self.userNameLabel];
    
    self.tableView.tableHeaderView = _tableViewHeaderView;
}

- (void)isLogin {
    NSString *path = NSSearchPathForDirectoriesInDomains(NSCachesDirectory, NSUserDomainMask, YES)[0];
    NSString *filePath = [path stringByAppendingPathComponent:@"user.data"];
    if ([[NSFileManager defaultManager] fileExistsAtPath:filePath]) {
        // 解档
        ZPLoginUserModel *model = [NSKeyedUnarchiver unarchiveObjectWithFile:filePath];
        [_photoImageView sd_setImageWithURL:[NSURL URLWithString:model.portrait] forState:UIControlStateNormal placeholderImage:[UIImage imageNamed:@"ic_ava"]];
        _userNameLabel.text = model.nickname;
    } else {
        _userNameLabel.text = @"SIGN IN";
        [_photoImageView sd_setImageWithURL:[NSURL URLWithString:@""] forState:UIControlStateNormal placeholderImage:[UIImage imageNamed:@"ic_ava"]];
    }
    
}

- (void)onLoginClicked {
    ZPLog(@"login");
    NSString *path = NSSearchPathForDirectoriesInDomains(NSCachesDirectory, NSUserDomainMask, YES)[0];
    NSString *filePath = [path stringByAppendingPathComponent:@"user.data"];
    if (![[NSFileManager defaultManager] fileExistsAtPath:filePath]) {
        ZPLoginViewController *loginController = [[ZPLoginViewController alloc] init];
        [loginController setModalTransitionStyle:UIModalTransitionStyleFlipHorizontal];
        ZPNavigationController *navi = [[ZPNavigationController alloc] initWithRootViewController:loginController];
        [self.navigationController presentViewController:navi animated:YES completion:nil];
    }
}


- (void)scrollViewDidScroll:(UIScrollView *)scrollView
{
    CGFloat width = self.view.frame.size.width;
    CGFloat yOffset = scrollView.contentOffset.y;
    if (yOffset < 0) {
        CGFloat totalOffset = _imageHeight + ABS(yOffset);
        CGFloat f = totalOffset / _imageHeight;
        self.headerBackView.frame = CGRectMake(- (width * f - width) / 2, yOffset, width * f, totalOffset);
    }
}

#pragma mark - datasource
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return self.data.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    ZPMeTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:NSStringFromClass([ZPMeTableViewCell class])];
    cell.dict = self.data[indexPath.row];
    return cell;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    return 54.f;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    NSString *path = NSSearchPathForDirectoriesInDomains(NSCachesDirectory, NSUserDomainMask, YES)[0];
    NSString *filePath = [path stringByAppendingPathComponent:@"user.data"];
    
    if (indexPath.row == 0) {
        if (![[NSFileManager defaultManager] fileExistsAtPath:filePath]) {
            [MBProgressHUD showError:@"Please login in first!"];
        } else {
            ZPMyDynamicsViewController *myDynamicsController = [[ZPMyDynamicsViewController alloc] init];
            [self.navigationController pushViewController:myDynamicsController animated:YES];
        }
    } else if (indexPath.row == 1) {
        if (![[NSFileManager defaultManager] fileExistsAtPath:filePath]) {
            [MBProgressHUD showError:@"Please login in first!"];
        } else {
            ZPLoginUserModel *model = [NSKeyedUnarchiver unarchiveObjectWithFile:filePath];
            if (model.teamMember) {
                [MBProgressHUD showSuccess:@"You are aleady a team member!"];
            } else {
                ZPApplyViewController *applyController = [[ZPApplyViewController alloc] init];
                [self.navigationController pushViewController:applyController animated:YES];
            }
        }
    } else if (indexPath.row == 2) {
        ZPHelpViewController *helpController = [[ZPHelpViewController alloc] init];
        [self.navigationController pushViewController:helpController animated:YES];
    } else if (indexPath.row == 3) {
        ZPAboutViewController *aboutController = [[ZPAboutViewController alloc] init];
        [self.navigationController pushViewController:aboutController animated:YES];
    }
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
//    [self.navigationController setNavigationBarHidden:YES animated:animated];
    [UIApplication sharedApplication].statusBarStyle = UIStatusBarStyleLightContent;
    [self isLogin];
    
}

- (void)viewWillDisappear:(BOOL)animated {
    [super viewWillDisappear:animated];
//    [self.navigationController setNavigationBarHidden:NO animated:animated];
}

#pragma mark - lazyload
- (NSArray *)data {
    if (!_data) {
        _data = @[@{@"icon":@"ic_me_service",@"title":@"My Dynamics"}
                  ,@{@"icon":@"ic_me_apply",@"title":@"Apply for team member"}
                  ,@{@"icon":@"ic_me_help",@"title":@"Help And FeedBack"}
                  ,@{@"icon":@"ic_me_about",@"title":@"About"}];
    }
    return _data;
}

- (UITableView *)tableView {
    if (!_tableView) {
        _tableView = [[UITableView alloc] initWithFrame:self.view.frame style:UITableViewStylePlain];
        [_tableView registerClass:[ZPMeTableViewCell class] forCellReuseIdentifier:NSStringFromClass([ZPMeTableViewCell class])];
        _tableView.dataSource = self;
        _tableView.delegate = self;
        _tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
        _tableView.tableFooterView = [UIView new];
        _tableView.backgroundColor = RGB(241, 241, 241);
    }
    return _tableView;
}
@end
