//
//  ZPAboutViewController.m
//  toudalianyuan
//
//  Created by Biao Geng on 2019/7/26.
//  Copyright © 2019年 Peng Zhou. All rights reserved.
//

#import "ZPAboutViewController.h"

@interface ZPAboutViewController ()
@property (nonatomic,strong) UIImageView *iconView;
@property (nonatomic,strong) UILabel *descLabel;
@end

@implementation ZPAboutViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self initUI];
     self.hbd_barHidden = NO;
}

- (void)initUI {
    self.title = @"About";
    self.view.backgroundColor = RGB(241, 241, 241);
    [self.view addSubview:self.iconView];
    [self.view addSubview:self.descLabel];
    
    self.iconView.sd_layout
    .topSpaceToView(self.view, 50)
    .centerXEqualToView(self.view)
    .heightIs(80)
    .widthIs(80);
    self.iconView.sd_cornerRadius = @10;
    self.descLabel.sd_layout
    .topSpaceToView(self.iconView, 20)
    .leftSpaceToView(self.view, 0)
    .rightSpaceToView(self.view, 0)
    .autoHeightRatio(0);
}

- (UIImageView *)iconView {
    if (!_iconView) {
        _iconView = [UIImageView new];
        _iconView.image = [UIImage imageNamed:@"icon"];
    }
    return _iconView;
}

- (UILabel *)descLabel {
    if (!_descLabel) {
        _descLabel = [[UILabel alloc] init];
        _descLabel.text = @"Royal Team exclusive app \n Share your wonderful game dynamics \(^o^)/~";
        _descLabel.textColor = RGB(185, 156, 98);
        _descLabel.font = [UIFont fontWithName:ZPPFSCRegular size:16];
        _descLabel.textAlignment = NSTextAlignmentCenter;
    }
    return _descLabel;
}

@end
