//
//  ZPHelpViewController.m
//  toudalianyuan
//
//  Created by Biao Geng on 2019/7/26.
//  Copyright © 2019年 Peng Zhou. All rights reserved.
//

#import "ZPHelpViewController.h"

@interface ZPHelpViewController ()
@property (nonatomic,strong) UIScrollView *scrollView;
@property (nonatomic,strong) UILabel *helpTitleLabel;
@property (nonatomic,strong) UILabel *helpDescLabel;
@property (nonatomic,strong) UILabel *contactTitleLabel;
@property (nonatomic,strong) UILabel *contactDescLabel;
@property (nonatomic,strong) UILabel *moreTitleLabel;
@end

@implementation ZPHelpViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self initUI];
}

- (void)initUI {
    self.title = @"Help And FeedBack";
    [self.view addSubview:self.scrollView];
    self.scrollView.sd_layout.spaceToSuperView(UIEdgeInsetsZero);
    [self.scrollView sd_addSubviews:@[self.helpTitleLabel,self.helpDescLabel,self.contactTitleLabel,self.contactDescLabel,self.moreTitleLabel]];
    self.helpTitleLabel.sd_layout
    .topSpaceToView(self.scrollView, 25)
    .leftSpaceToView(self.scrollView, 20)
    .rightSpaceToView(self.scrollView, 20)
    .autoHeightRatio(0);
    
    self.helpDescLabel.sd_layout
    .topSpaceToView(self.helpTitleLabel, 20)
    .leftSpaceToView(self.scrollView, 20)
    .rightSpaceToView(self.scrollView, 20)
    .autoHeightRatio(0);
    
    self.contactTitleLabel.sd_layout
    .topSpaceToView(self.helpDescLabel, 25)
    .leftSpaceToView(self.scrollView, 20)
    .rightSpaceToView(self.scrollView, 20)
    .autoHeightRatio(0);
    
    self.contactDescLabel.sd_layout
    .topSpaceToView(self.contactTitleLabel, 20)
    .leftSpaceToView(self.scrollView, 20)
    .rightSpaceToView(self.scrollView, 20)
    .autoHeightRatio(0);
    
    self.moreTitleLabel.sd_layout
    .topSpaceToView(self.contactDescLabel, 25)
    .leftSpaceToView(self.scrollView, 20)
    .rightSpaceToView(self.scrollView, 20)
    .autoHeightRatio(0);
    
    [self.scrollView setupAutoContentSizeWithBottomView:self.moreTitleLabel bottomMargin:25];
}

- (UIScrollView *)scrollView {
    if (!_scrollView) {
        _scrollView = [[UIScrollView alloc] init];
        _scrollView.backgroundColor = RGB(241, 241, 241);
    }
    return _scrollView;
}

- (UILabel *)helpTitleLabel {
    if (!_helpTitleLabel) {
        _helpTitleLabel = [[UILabel alloc] init];
        _helpTitleLabel.text = @"Help";
        _helpTitleLabel.textColor = RGB(185, 156, 98);
        _helpTitleLabel.font = [UIFont fontWithName:ZPPFSCRegular size:16];
    }
    return _helpTitleLabel;
}

- (UILabel *)helpDescLabel {
    if (!_helpDescLabel) {
        _helpDescLabel = [[UILabel alloc] init];
        _helpDescLabel.text = @"1. A member of the Royal Team, you can choose to publish wonderful dynamic of the game. (Everyone can see it, please pay attention to privacy.)\n\n2. My activity: You can delete the dynamics you posted, but you can't edit them. \n\n3. Team member information: If you have any information that needs to be modified or added, please contact us to add. \n\n4. Note: Do not post any illegal or illegal information. (Welcome to report)";
        _helpDescLabel.textColor = [UIColor blackColor];
        _helpDescLabel.font = [UIFont fontWithName:ZPPFSCRegular size:14];
    }
    return _helpDescLabel;
}

- (UILabel *)contactTitleLabel {
    if (!_contactTitleLabel) {
        _contactTitleLabel = [[UILabel alloc] init];
        _contactTitleLabel.text = @"Contact";
        _contactTitleLabel.textColor = RGB(185, 156, 98);
        _contactTitleLabel.font = [UIFont fontWithName:ZPPFSCRegular size:16];
    }
    return _contactTitleLabel;
}

- (UILabel *)contactDescLabel {
    if (!_contactDescLabel) {
        _contactDescLabel = [[UILabel alloc] init];
        _contactDescLabel.text = @"Have any comments or suggestions, welcome feedback to us: )\n\n* Email：437383092@qq.com";
        _contactDescLabel.textColor = [UIColor blackColor];
        _contactDescLabel.font = [UIFont fontWithName:ZPPFSCRegular size:14];
    }
    return _contactDescLabel;
}

- (UILabel *)moreTitleLabel {
    if (!_moreTitleLabel) {
        _moreTitleLabel = [[UILabel alloc] init];
        _moreTitleLabel.text = @"As time goes by, we are always there.";
        _moreTitleLabel.textColor = RGB(185, 156, 98);
        _moreTitleLabel.font = [UIFont fontWithName:ZPPFSCRegular size:16];
    }
    return _moreTitleLabel;
}
@end
