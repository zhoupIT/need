//
//  ZPMyDynamicsViewController.m
//  toudalianyuan
//
//  Created by Biao Geng on 2019/7/29.
//  Copyright © 2019年 Peng Zhou. All rights reserved.
//

#import "ZPMyDynamicsViewController.h"
#import "ZPDynamicTableviewCell.h"
#import "ZPDynamicModel.h"
#import "ZPNetWork.h"
@interface ZPMyDynamicsViewController ()<UITableViewDataSource,UITableViewDelegate>
@property (nonatomic,strong) UITableView *tableView;
@property (nonatomic,strong) NSMutableArray *dynamicData;

@property (nonatomic,assign) NSInteger page;
@end

@implementation ZPMyDynamicsViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self initUI];
}

- (void)initUI {
    self.title = @"My Dynamics";
    self.view.backgroundColor = RGB(241, 241, 241);
    [self.view sd_addSubviews:@[self.tableView]];
    //dynamic tableView
    self.tableView.sd_layout
    .topSpaceToView(self.view, 0)
    .leftEqualToView(self.view)
    .rightEqualToView(self.view)
    .bottomEqualToView(self.view);
    WEAK_SELF(weakSelf);
    self.tableView.mj_header = [MJRefreshNormalHeader headerWithRefreshingBlock:^{
        [weakSelf getMyDynamics];
    }];
    [self.tableView.mj_header beginRefreshing];
    //footer
    self.tableView.mj_footer = [MJRefreshBackNormalFooter footerWithRefreshingTarget:self refreshingAction:@selector(loadMoreData)];
}

- (void)getMyDynamics {
    WEAK_SELF(weakSelf);
    [[ZPNetWorkTool sharedZPNetWorkTool] GETRequestWith:@"shareList" parameters:@{@"limit":@10,@"userId":[kUSER_DEFAULT objectForKey:@"ownID"]} progress:^(NSProgress *progress) {
        
    } success:^(NSURLSessionDataTask *task, id response) {
        //reset the page
        weakSelf.page = 0;
        weakSelf.dynamicData = [ZPDynamicModel mj_objectArrayWithKeyValuesArray:[response objectForKey:@"data"]];
        [weakSelf.tableView reloadData];
        [weakSelf.tableView.mj_header endRefreshing];
    } failed:^(NSURLSessionDataTask *task, NSError *error) {
        [weakSelf.tableView.mj_header endRefreshing];
    } className:[ZPMyDynamicsViewController class]];
}

- (void)loadMoreData {
    self.page ++;
    WEAK_SELF(weakSelf);
    [[ZPNetWorkTool sharedZPNetWorkTool] GETRequestWith:@"shareList" parameters:@{@"limit":@10,@"offset":[NSNumber numberWithInteger:10*self.page],@"userId":[kUSER_DEFAULT objectForKey:@"ownID"]} progress:^(NSProgress *progress) {
        
    } success:^(NSURLSessionDataTask *task, id response) {
        if ([[response objectForKey:@"data"] count]) {
            [weakSelf.dynamicData addObjectsFromArray:[ZPDynamicModel mj_objectArrayWithKeyValuesArray:[response objectForKey:@"data"]]];
            [weakSelf.tableView reloadData];
            [weakSelf.tableView.mj_footer endRefreshing];
        } else {
            [weakSelf.tableView.mj_footer endRefreshingWithNoMoreData];
        }
    } failed:^(NSURLSessionDataTask *task, NSError *error) {
        weakSelf.page --;
        [weakSelf.tableView.mj_footer endRefreshing];
    } className:[ZPMyDynamicsViewController class]];
}

#pragma mark - datasource
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return self.dynamicData.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    ZPDynamicTableviewCell *cell = [tableView dequeueReusableCellWithIdentifier:NSStringFromClass([ZPDynamicTableviewCell class])];
    cell.dynamicModel = self.dynamicData[indexPath.row];
    cell.dynamicResultType = ZPDynamicResultType_My;
    WEAK_SELF(weakSelf);
    cell.onShowMoreBlock = ^(ZPDynamicModel * _Nonnull dynamicModel) {
        [weakSelf chooseActionWithDynamicModel:dynamicModel withIndex:indexPath.row];
    };
    return cell;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    ZPDynamicModel *model = self.dynamicData[indexPath.row];
    return [tableView cellHeightForIndexPath:indexPath model:model keyPath:@"dynamicModel" cellClass:[ZPDynamicTableviewCell class] contentViewWidth:SCREEN_WIDTH];
}

#pragma mark - privite
-(void)chooseActionWithDynamicModel:(ZPDynamicModel *)model withIndex:(NSInteger)index{
    if ([kUSER_DEFAULT objectForKey:@"ownID"]) {
        WEAK_SELF(weakSelf);
        UIAlertController *actionSheet = [UIAlertController alertControllerWithTitle:@"Tip" message:@"Are you sure to delete the content?" preferredStyle:UIAlertControllerStyleActionSheet];
        
        UIAlertAction *action_delete = [UIAlertAction actionWithTitle:@"Delete" style:UIAlertActionStyleDestructive handler:^(UIAlertAction * _Nonnull action) {
            ZPLog(@"Delete");
            [[ZPNetWork sharedZPNetWork] requestWithUrl:[NSString stringWithFormat:@"/api/share/del/%@",model.ID] andHTTPMethod:@"DELETE" andDict:nil success:^(NSDictionary *response) {
                [MBProgressHUD showSuccess:@"Delete Success!"];
                [weakSelf getMyDynamics];
            } failed:^(NSError *error) {
                
            }];
        }];
        UIAlertAction *action_cancel = [UIAlertAction actionWithTitle:@"Cancel" style:UIAlertActionStyleCancel handler:nil];
        [actionSheet addAction:action_delete];
        [actionSheet addAction:action_cancel];
        [self presentViewController:actionSheet animated:YES completion:nil];
    } else {
        [MBProgressHUD showError:@"Please login in first!"];
    }
}

#pragma mark - lazyload
- (UITableView *)tableView {
    if (!_tableView) {
        _tableView = [[UITableView alloc] initWithFrame:CGRectZero style:UITableViewStylePlain];
        _tableView.backgroundColor = RGB(241, 241, 241);
        _tableView.dataSource = self;
        _tableView.delegate = self;
        _tableView.tableFooterView = [UIView new];
        _tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
        [_tableView registerClass:[ZPDynamicTableviewCell class] forCellReuseIdentifier:NSStringFromClass([ZPDynamicTableviewCell class])];
    }
    return _tableView;
}

- (NSMutableArray *)dynamicData {
    if (!_dynamicData) {
        _dynamicData = [NSMutableArray arrayWithCapacity:0];
    }
    return _dynamicData;
}
@end
