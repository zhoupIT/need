//
//  NSString+MD5.h
//  PKWSevers
//
//  Created by peikua on 16/4/27.
//  Copyright © 2016年 peikua. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSString (HPMD5)

/** MD5加密 */
- (NSString *) md5WithString;

@end
